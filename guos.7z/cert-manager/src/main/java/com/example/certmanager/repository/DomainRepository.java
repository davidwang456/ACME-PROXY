package com.example.certmanager.repository;

import com.example.certmanager.model.Domain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 域名仓库接口
 * 用于域名实体的数据库操作
 */
@Repository
public interface DomainRepository extends JpaRepository<Domain, Long> {
    
    /**
     * 根据域名查找域名实体
     * @param domainName 域名
     * @return 域名实体
     */
    Optional<Domain> findByDomainName(String domainName);
    
    /**
     * 根据域名类型查找域名实体列表
     * @param domainType 域名类型
     * @return 域名实体列表
     */
    List<Domain> findByDomainType(Domain.DomainType domainType);
    
    /**
     * 根据活动状态查找域名实体列表
     * @param active 活动状态
     * @return 域名实体列表
     */
    List<Domain> findByActive(boolean active);
    
    /**
     * 查找活动状态为true且证书即将过期的域名实体列表
     * @param expiryDate 过期日期阈值
     * @return 即将过期的域名实体列表
     */
    List<Domain> findByActiveTrueAndCertificateExpiresAtBefore(LocalDateTime expiryDate);
    
    /**
     * 查找活动状态为true且证书已过期的域名实体列表
     * @return 已过期的域名实体列表
     */
    @Query("SELECT d FROM Domain d WHERE d.active = true AND d.certificateExpiresAt < CURRENT_TIMESTAMP")
    List<Domain> findExpiredCertificates();
}