package com.example.certmanager.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * DNS挑战实体类
 * 用于存储DNS-01挑战的相关信息
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dns_challenges")
public class DnsChallenge {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String domain;
    
    @Column(nullable = false)
    private String rrName; // DNS记录名称，例如 _acme-challenge.example.com
    
    @Column(nullable = false, length = 1024)
    private String txtValue; // DNS TXT记录值
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ChallengeStatus status = ChallengeStatus.PENDING;
    
    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    
    @Column(nullable = true)
    private LocalDateTime completedAt;
    
    @Column(nullable = true)
    private String orderUrl; // ACME订单URL，用于后续操作
    
    @Column(nullable = true)
    private String authorizationUrl; // ACME授权URL
    
    @Column(nullable = true)
    private String challengeUrl; // ACME挑战URL
    
    @ManyToOne
    @JoinColumn(name = "domain_id")
    private Domain domainEntity; // 关联的域名实体
    
    /**
     * 挑战状态枚举
     */
    public enum ChallengeStatus {
        PENDING,    // 等待验证
        COMPLETED,  // 验证完成
        FAILED      // 验证失败
    }
}