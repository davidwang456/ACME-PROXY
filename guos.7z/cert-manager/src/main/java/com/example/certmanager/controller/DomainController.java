package com.example.certmanager.controller;

import com.example.certmanager.model.Domain;
import com.example.certmanager.service.DomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Slf4j
@Controller
@RequestMapping("/domains")
public class DomainController {

    private final DomainService domainService;

    @Autowired
    public DomainController(DomainService domainService) {
        this.domainService = domainService;
    }

    @GetMapping
    public String listDomains(Model model) {
        List<Domain> domains = domainService.findAll();
        model.addAttribute("domains", domains);
        return "domains/list";
    }

    @GetMapping("/add")
    public String showAddDomainForm(Model model) {
        model.addAttribute("domain", new Domain());
        return "domains/add";
    }

    @PostMapping("/add")
    public String addDomain(@ModelAttribute Domain domain, RedirectAttributes redirectAttributes) {
        try {
            domainService.addDomain(domain);
            redirectAttributes.addFlashAttribute("successMessage", "域名添加成功");
            return "redirect:/domains";
        } catch (Exception e) {
            log.error("Failed to add domain", e);
            redirectAttributes.addFlashAttribute("errorMessage", "域名添加失败: " + e.getMessage());
            return "redirect:/domains/add";
        }
    }

    @GetMapping("/{id}")
    public String viewDomain(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        return domainService.findById(id)
                .map(domain -> {
                    model.addAttribute("domain", domain);
                    return "domains/view";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("errorMessage", "域名不存在");
                    return "redirect:/domains";
                });
    }

    @PostMapping("/{id}/issue-certificate")
    public String issueCertificate(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            domainService.issueCertificate(id);
            redirectAttributes.addFlashAttribute("successMessage", "证书签发成功");
        } catch (Exception e) {
            log.error("Failed to issue certificate", e);
            redirectAttributes.addFlashAttribute("errorMessage", "证书签发失败: " + e.getMessage());
        }
        return "redirect:/domains/" + id;
    }

    @PostMapping("/{id}/revoke-certificate")
    public String revokeCertificate(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            domainService.revokeCertificate(id);
            redirectAttributes.addFlashAttribute("successMessage", "证书撤销成功");
        } catch (Exception e) {
            log.error("Failed to revoke certificate", e);
            redirectAttributes.addFlashAttribute("errorMessage", "证书撤销失败: " + e.getMessage());
        }
        return "redirect:/domains/" + id;
    }

    @PostMapping("/{id}/renew-certificate")
    public String renewCertificate(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            domainService.renewCertificate(id);
            redirectAttributes.addFlashAttribute("successMessage", "证书续期成功");
        } catch (Exception e) {
            log.error("Failed to renew certificate", e);
            redirectAttributes.addFlashAttribute("errorMessage", "证书续期失败: " + e.getMessage());
        }
        return "redirect:/domains/" + id;
    }

    @PostMapping("/{id}/delete")
    public String deleteDomain(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            domainService.deleteDomain(id);
            redirectAttributes.addFlashAttribute("successMessage", "域名删除成功");
        } catch (Exception e) {
            log.error("Failed to delete domain", e);
            redirectAttributes.addFlashAttribute("errorMessage", "域名删除失败: " + e.getMessage());
        }
        return "redirect:/domains";
    }

    @GetMapping("/type/{type}")
    public String listDomainsByType(@PathVariable String type, Model model, RedirectAttributes redirectAttributes) {
        try {
            Domain.DomainType domainType = Domain.DomainType.valueOf(type.toUpperCase());
            List<Domain> domains = domainService.findByDomainType(domainType);
            model.addAttribute("domains", domains);
            model.addAttribute("currentType", domainType);
            return "domains/list";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", "无效的域名类型");
            return "redirect:/domains";
        }
    }
}