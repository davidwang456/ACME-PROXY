package com.example.certmanager.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "domains")
public class Domain {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String domainName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DomainType domainType;
    
    @Column(nullable = true)
    private LocalDateTime certificateIssuedAt;
    
    @Column(nullable = true)
    private LocalDateTime certificateExpiresAt;
    
    @Column(nullable = true, length = 2048)
    private String certificatePath;
    
    @Column(nullable = true, length = 2048)
    private String privateKeyPath;
    
    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    
    @Column(nullable = false)
    private boolean active = true;
    
    public enum DomainType {
        INTERNAL, // *.csky, *.asky
        EXTERNAL  // .com.hk
    }
    
    // Helper method to determine domain type based on domain name
    public static DomainType determineDomainType(String domainName) {
        if (domainName == null) {
            return null;
        }
        
        if (domainName.endsWith(".csky") || domainName.endsWith(".asky")) {
            return DomainType.INTERNAL;
        } else if (domainName.endsWith(".com.hk")||domainName.endsWith(".com")) {
            return DomainType.EXTERNAL;
        }
        
        return null; // Invalid domain type
    }
}