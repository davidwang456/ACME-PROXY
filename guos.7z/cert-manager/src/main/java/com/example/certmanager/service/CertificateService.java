package com.example.certmanager.service;

import com.example.certmanager.model.Domain;

import java.security.KeyPair;


public interface CertificateService {
    
    /**
     * 生成密钥对
     * @return 生成的密钥对
     */
    KeyPair generateKeyPair() throws Exception;
    
    /**
     * 为指定域名签发证书
     * @param domain 域名实体
     * @return 更新后的域名实体
     */
    Domain issueCertificate(Domain domain) throws Exception;
    
    /**
     * 验证证书是否有效
     * @param domain 域名实体
     * @return 证书是否有效
     */
    boolean validateCertificate(Domain domain);
    
    /**
     * 撤销证书
     * @param domain 域名实体
     * @return 更新后的域名实体
     */
    Domain revokeCertificate(Domain domain) throws Exception;
    
    /**
     * 续期证书
     * @param domain 域名实体
     * @return 更新后的域名实体
     */
    Domain renewCertificate(Domain domain) throws Exception;

    public String getCAServerUrl() ;
    
    public String getCAProvisioner();
}