package com.example.certmanager.controller;

import com.example.certmanager.model.Domain;
import com.example.certmanager.service.CertificateService;
import com.example.certmanager.service.DomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.net.InetAddress;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 证书管理控制器
 * 处理证书管理相关的Web请求和API请求
 */
@Slf4j
@Controller
@RequestMapping("/certificates")
public class CertificateController {

    private final DomainService domainService;
    private final CertificateService letsEncryptCertificateService;
    private final CertificateService stepCACertificateService;
    
    @Autowired
    public CertificateController(
            DomainService domainService,
            @Qualifier("letsEncryptCertificateService") CertificateService letsEncryptCertificateService,
            @Qualifier("stepCACertificateService") CertificateService stepCACertificateService) {
        this.domainService = domainService;
        this.letsEncryptCertificateService = letsEncryptCertificateService;
        this.stepCACertificateService = stepCACertificateService;
        
        // Log connectivity information at startup
        try {
            log.info("Checking connectivity to Step CA server...");
            InetAddress stepCaAddress = InetAddress.getByName("ca.itd.asky");
            boolean reachable = stepCaAddress.isReachable(5000); // 5 second timeout
            log.info("Step CA server (ca.itd.asky) is reachable: {}", reachable);
            log.info("Step CA server IP: {}", stepCaAddress.getHostAddress());
        } catch (Exception e) {
            log.error("Failed to check connectivity to Step CA server", e);
        }
    }

    /**
     * 显示证书管理仪表板
     * @param model 模型
     * @return 视图名称
     */
    @GetMapping
    public String showDashboard(Model model) {
        List<Domain> domains = domainService.findAll();
        
        int totalDomains = domains.size();
        int validCerts = 0;
        int expiredCerts = 0;
        int noCerts = 0;
        
        LocalDateTime now = LocalDateTime.now();
        
        for (Domain domain : domains) {
            if (domain.getCertificatePath() == null) {
                noCerts++;
            } else if (domain.getCertificateExpiresAt() != null && domain.getCertificateExpiresAt().isBefore(now)) {
                expiredCerts++;
            } else {
                validCerts++;
            }
        }
        
        model.addAttribute("totalDomains", totalDomains);
        model.addAttribute("validCerts", validCerts);
        model.addAttribute("expiredCerts", expiredCerts);
        model.addAttribute("noCerts", noCerts);
        model.addAttribute("domains", domains);
        
        return "certificates/dashboard";
    }

    /**
     * 显示证书详情
     * @param id 域名ID
     * @param model 模型
     * @param redirectAttributes 重定向属性
     * @return 视图名称
     */
    @GetMapping("/{id}")
    public String viewCertificate(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        return domainService.findById(id)
                .map(domain -> {
                    model.addAttribute("domain", domain);
                    
                    // 检查证书是否有效
                    boolean isValid = false;
                    if (domain.getCertificatePath() != null && domain.getCertificateExpiresAt() != null) {
                        isValid = domain.getCertificateExpiresAt().isAfter(LocalDateTime.now());
                    }
                    model.addAttribute("isValid", isValid);
                    
                    return "certificates/view";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("error", "Domain not found with id: " + id);
                    return "redirect:/certificates";
                });
    }

    /**
     * 提供证书状态API接口
     * @return 证书状态信息
     */
    @GetMapping("/api/status")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getCertificateStatus() {
        List<Domain> domains = domainService.findAll();
        
        int totalDomains = domains.size();
        int validCerts = 0;
        int expiredCerts = 0;
        int noCerts = 0;
        
        LocalDateTime now = LocalDateTime.now();
        
        for (Domain domain : domains) {
            if (domain.getCertificatePath() == null) {
                noCerts++;
            } else if (domain.getCertificateExpiresAt() != null && domain.getCertificateExpiresAt().isBefore(now)) {
                expiredCerts++;
            } else {
                validCerts++;
            }
        }
        
        Map<String, Object> status = new HashMap<>();
        status.put("totalDomains", totalDomains);
        status.put("validCertificates", validCerts);
        status.put("expiredCertificates", expiredCerts);
        status.put("domainsWithoutCertificates", noCerts);
        status.put("timestamp", now);
        
        return ResponseEntity.ok(status);
    }

    /**
     * 批量续期过期证书
     * @param redirectAttributes 重定向属性
     * @return 重定向URL
     */
    @PostMapping("/renew-expired")
    public String renewExpiredCertificates(RedirectAttributes redirectAttributes) {
        try {
            List<Domain> expiredDomains = domainService.findExpiredCertificates();
            int renewedCount = 0;
            
            for (Domain domain : expiredDomains) {
                try {
                    domainService.renewCertificate(domain.getId());
                    renewedCount++;
                } catch (Exception e) {
                    log.error("Failed to renew certificate for domain: {}", domain.getDomainName(), e);
                }
            }
            
            redirectAttributes.addFlashAttribute("success", "Successfully renewed " + renewedCount + " out of " + expiredDomains.size() + " expired certificates");
        } catch (Exception e) {
            log.error("Failed to renew expired certificates", e);
            redirectAttributes.addFlashAttribute("error", "Failed to renew expired certificates: " + e.getMessage());
        }
        
        return "redirect:/certificates";
    }
    
    /**
     * 测试与Step CA服务器的连接
     */
    @GetMapping("/test-connectivity")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> testConnectivity() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // Test DNS resolution
            InetAddress stepCaAddress = InetAddress.getByName("ca.itd.asky");
            result.put("dnsResolution", true);
            result.put("ipAddress", stepCaAddress.getHostAddress());
            
            // Test reachability
            boolean reachable = stepCaAddress.isReachable(5000);
            result.put("reachable", reachable);
            
            // Test port connectivity
            try {
                java.net.Socket socket = new java.net.Socket();
                socket.connect(new java.net.InetSocketAddress(stepCaAddress, 9000), 5000);
                result.put("portConnectivity", true);
                socket.close();
            } catch (Exception e) {
                result.put("portConnectivity", false);
                result.put("portError", e.getMessage());
            }
            
            // Test HTTPS connectivity
            try {
                java.net.URL url = new java.net.URL("https://ca.itd.asky:9000/acme/acme/directory");
                java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestMethod("GET");
                
                // For self-signed certificates
                if (connection instanceof javax.net.ssl.HttpsURLConnection) {
                    javax.net.ssl.HttpsURLConnection httpsConnection = (javax.net.ssl.HttpsURLConnection) connection;
                    httpsConnection.setHostnameVerifier((hostname, session) -> true);
                    
                    javax.net.ssl.SSLContext sslContext = javax.net.ssl.SSLContext.getInstance("TLS");
                    sslContext.init(null, new javax.net.ssl.TrustManager[] { 
                        new javax.net.ssl.X509TrustManager() {
                            public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                            public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                            public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                        }
                    }, new java.security.SecureRandom());
                    
                    httpsConnection.setSSLSocketFactory(sslContext.getSocketFactory());
                }
                
                int responseCode = connection.getResponseCode();
                result.put("httpsConnectivity", true);
                result.put("httpResponseCode", responseCode);
                
                // Read response if available
                if (responseCode == 200) {
                    try (java.io.BufferedReader reader = new java.io.BufferedReader(
                            new java.io.InputStreamReader(connection.getInputStream()))) {
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        result.put("httpResponse", response.toString());
                    }
                }
            } catch (Exception e) {
                result.put("httpsConnectivity", false);
                result.put("httpsError", e.getMessage());
            }
            
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
            log.error("Failed to test connectivity to Step CA server", e);
        }
        
        return ResponseEntity.ok(result);
    }
    
    /**
     * 诊断证书签发问题
     */
    @GetMapping("/diagnose")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> diagnoseCertificateIssues() {
        Map<String, Object> diagnostics = new HashMap<>();
        
        // Check Step CA connectivity
        diagnostics.put("stepCaConnectivity", testConnectivity().getBody());
        
        // Check Java environment
        diagnostics.put("javaVersion", System.getProperty("java.version"));
        diagnostics.put("javaHome", System.getProperty("java.home"));
        
        // Check security providers
        List<String> securityProviders = new ArrayList<>();
        for (java.security.Provider provider : java.security.Security.getProviders()) {
            securityProviders.add(provider.getName() + " - " + provider.getVersion());
        }
        diagnostics.put("securityProviders", securityProviders);
        
        // Check if BouncyCastle is properly registered
        // 修复语法错误，删除多余的空格
        diagnostics.put("bouncyCastleAvailable", java.security.Security.getProvider("BC") != null);
        
        // 修复方法名称错误，使用正确的方法名
        try {
            if (stepCACertificateService instanceof com.example.certmanager.service.impl.StepCACertificateService) {
                com.example.certmanager.service.impl.StepCACertificateService service = 
                    (com.example.certmanager.service.impl.StepCACertificateService) stepCACertificateService;
                diagnostics.put("stepCaServerUrl", service.getCAServerUrl());
                diagnostics.put("stepCaProvisioner", service.getCAProvisioner());
            } else {
                diagnostics.put("stepCaServiceClass", stepCACertificateService.getClass().getName());
            }
        } catch (Exception e) {
            diagnostics.put("configError", e.getMessage());
        }
        
        return ResponseEntity.ok(diagnostics);
    }
    
    /**
     * 使用ACME协议签发证书
     */
    @PostMapping("/issue-acme")
    public String issueAcmeCertificate(@RequestParam Long domainId, @RequestParam(required = false) boolean useWildcard,
RedirectAttributes redirectAttributes) {
        try {
            Domain domain = domainService.findById(domainId)
                    .orElseThrow(() -> new IllegalArgumentException("域名不存在: " + domainId));
            
            // 如果需要通配符证书，修改域名格式
            if (useWildcard && !domain.getDomainName().startsWith("*.")) {
                domain.setDomainName("*." + domain.getDomainName());
                domain = domainService.save(domain);
            }
            
            // 根据域名类型选择合适的证书服务
            CertificateService certService;
            if (domain.getDomainType() == Domain.DomainType.INTERNAL) {
                certService = stepCACertificateService;
                log.info("使用Step CA为内部域名签发证书: {}", domain.getDomainName());
            } else {
                certService = letsEncryptCertificateService;
                log.info("使用Let's Encrypt为外部域名签发证书: {}", domain.getDomainName());
            }
            
            // 签发证书
            Domain updatedDomain = certService.issueCertificate(domain);
            
            redirectAttributes.addFlashAttribute("success", 
                    String.format("成功为域名 %s 签发证书，有效期至 %s", 
                            updatedDomain.getDomainName(), 
                            updatedDomain.getCertificateExpiresAt()));
            
            return "redirect:/certificates/" + updatedDomain.getId();
        } catch (Exception e) {
            log.error("使用ACME签发证书失败", e);
            redirectAttributes.addFlashAttribute("error", "签发证书失败: " + e.getMessage());
            return "redirect:/certificates";
        }
    }
    
    /**
     * 添加信任所有证书的功能（仅用于开发环境）
     */
    @PostMapping("/trust-all-certificates")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> trustAllCertificates() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 创建一个不验证证书链的信任管理器
            javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[] {
                new javax.net.ssl.X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                }
            };
            
            // 安装全信任的信任管理器
            javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            
            // 安装信任所有主机名的验证器
            javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
            
            result.put("success", true);
            result.put("message", "已配置信任所有证书（警告：这不安全，仅应在开发环境中使用）");
            
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
            log.error("配置信任所有证书失败", e);
        }
        
        return ResponseEntity.ok(result);
    }
}