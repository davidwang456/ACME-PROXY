package com.example.certmanager.service;

import com.example.certmanager.model.DnsChallenge;
import org.shredzone.acme4j.Authorization;
import org.shredzone.acme4j.Order;

import java.util.List;
import java.util.Optional;

/**
 * DNS挑战服务接口
 * 用于管理DNS-01挑战的相关操作
 */
public interface DnsChallengeService {
    
    /**
     * 查找所有DNS挑战记录
     * @return DNS挑战记录列表
     */
    List<DnsChallenge> findAll();
    
    /**
     * 根据域名查找DNS挑战记录
     * @param domain 域名
     * @return DNS挑战记录
     */
    Optional<DnsChallenge> findByDomain(String domain);
    
    /**
     * 创建DNS挑战记录
     * @param domain 域名
     * @param rrName DNS记录名称
     * @param txtValue DNS TXT记录值
     * @param orderUrl ACME订单URL
     * @param authorizationUrl ACME授权URL
     * @param challengeUrl ACME挑战URL
     * @return 创建的DNS挑战记录
     */
    DnsChallenge createChallenge(String domain, String rrName, String txtValue, 
                                String orderUrl, String authorizationUrl, String challengeUrl);
    
    /**
     * 从ACME授权创建DNS挑战记录
     * @param domain 域名
     * @param authorization ACME授权
     * @param order ACME订单
     * @return 创建的DNS挑战记录
     */
    DnsChallenge createChallengeFromAuthorization(String domain, Authorization authorization, Order order);
    
    /**
     * 将DNS挑战标记为已完成
     * @param domain 域名
     * @return 更新后的DNS挑战记录
     */
    DnsChallenge markAsCompleted(String domain);
    
    /**
     * 将DNS挑战标记为失败
     * @param domain 域名
     * @param errorMessage 错误信息
     * @return 更新后的DNS挑战记录
     */
    DnsChallenge markAsFailed(String domain, String errorMessage);
    
    /**
     * 删除DNS挑战记录
     * @param domain 域名
     */
    void deleteChallenge(String domain);
    
    /**
     * 清理过期的DNS挑战记录
     * @param days 天数，超过这个天数的记录将被清理
     * @return 清理的记录数
     */
    int cleanupExpiredChallenges(int days);
}