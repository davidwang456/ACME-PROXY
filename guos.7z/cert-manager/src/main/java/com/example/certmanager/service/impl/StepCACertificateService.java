package com.example.certmanager.service.impl;

import com.example.certmanager.model.Domain;
import com.example.certmanager.common.ACMETools;
import com.example.certmanager.repository.DomainRepository;
import com.example.certmanager.service.CertificateService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

@Slf4j
@Service
public class StepCACertificateService implements CertificateService {

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    @Value("${stepca.server.url}")
    private String stepCAServerUrl;

    @Value("${stepca.provisioner}")
    private String stepCAProvisioner;
    
    // Add a new property for the ACME directory URL
    @Value("${stepca.acme.directory:${stepca.server.url}/acme/acme/directory}")
    private String stepCaAcmeDirectory;

    private final DomainRepository domainRepository;
  //  @Value("${stepca.key.dir}")
    private  String KEYS_DIR = "certificates/keys";
  //  @Value("${stepca.cert.dir}")
    private  String CERTS_DIR = "certificates/certs";
  //  @Value("${stepca.ca.dir}")
    private  String STEP_CA_DIR = "certificates/step-ca";

    @Autowired
    public StepCACertificateService(DomainRepository domainRepository) {
        this.domainRepository = domainRepository;
        // 确保证书和密钥目录存在
        createDirectories();
    }

    private void createDirectories() {
        try {
            Files.createDirectories(Paths.get(KEYS_DIR));
            Files.createDirectories(Paths.get(CERTS_DIR));
            Files.createDirectories(Paths.get(STEP_CA_DIR));
        } catch (IOException e) {
            log.error("Failed to create certificate directories", e);
        }
    }

    @Override
    public KeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        return keyGen.generateKeyPair();
    }

    @Override
    public Domain issueCertificate(Domain domain) throws Exception {
        if (domain.getDomainType() != Domain.DomainType.INTERNAL) {
            throw new IllegalArgumentException("Step-CA service can only issue certificates for internal domains");
        }
    
        String domainName = domain.getDomainName();
        
        // 生成域名密钥对
        KeyPair domainKeyPair = generateKeyPair();
        String keyPath = saveKeyPair(domainKeyPair, domainName);
        
        // 生成CSR文件
        String csrPath = generateCSR(domainKeyPair, domainName);
        
        // 调用Step-CA API签发证书
        String certPath;
        if (domainName.startsWith("*.")) {
            // 对于通配符域名，使用JWK提供者而不是ACME
            certPath = requestCertificateForWildcard(csrPath, domainName);
        } else {
            // 对于普通域名，继续使用ACME提供者
            certPath = requestCertificateFromStepCA(csrPath, domainName);
        }
        
        // 读取证书信息
        X509Certificate cert = readCertificate(certPath);
        
        // 更新域名信息
        domain.setCertificatePath(certPath);
        domain.setPrivateKeyPath(keyPath);
        domain.setCertificateIssuedAt(LocalDateTime.now());
        domain.setCertificateExpiresAt(
                LocalDateTime.ofInstant(cert.getNotAfter().toInstant(), ZoneId.systemDefault()));
        
        return domainRepository.save(domain);
    }
    
    // 添加ACMETools的注入
    @Autowired
    private ACMETools acmeTools;
    
    // 修改requestCertificateForWildcard方法，添加更详细的网络错误处理
    private String requestCertificateForWildcard(String csrPath, String domainName) throws Exception {
        // 使用ACME协议处理通配符域名
        String certFileName = domainName.replace("*", "wildcard").replace(".", "_") + ".crt";
        Path certPath = Paths.get(CERTS_DIR, certFileName);
        
        // 从CSR中提取公钥，或者直接使用之前生成的密钥对
        // 这里我们简化处理，直接生成新的密钥对
        KeyPair domainKeyPair = generateKeyPair();
        
        try {
            // 确保HTTPS连接配置正确
            configureHttpsForStepCA();
            
            // 测试与ACME服务器的连接
            testAcmeServerConnection();
            
            log.info("start to get cert from acme: {}", domainName);
            log.info("ACME directory URL: {}", stepCaAcmeDirectory);
            
            // 调用ACMETools签发通配符证书
            return acmeTools.issueWildcardCertificate(domainName, domainKeyPair, certPath.toString());
        } catch (Exception e) {
            log.error("通过ACME签发通配符证书失败", e);
            // 添加更详细的错误信息
            if (e.getMessage().contains("Network error") || e.getMessage().contains("Connection")) {
                log.error("ACME服务器网络连接错误，请检查网络连接和服务器状态");
                log.error("ACME服务器URL: {}", stepCaAcmeDirectory);
                
                // 尝试诊断网络问题
                Map<String, Object> diagnostics = testAcmeServerConnection();
                log.error("网络诊断结果: {}", diagnostics);
            }
            throw new Exception("通过ACME签发通配符证书失败: " + e.getMessage(), e);
        }
    }
    
    /**
     * 测试与ACME服务器的连接
     * @return 连接测试结果
     */
    public Map<String, Object> testAcmeServerConnection() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 从ACME目录URL中提取主机名和端口
            URL acmeUrl = new URL(stepCaAcmeDirectory);
            String acmeServer = acmeUrl.getHost();
            int port = acmeUrl.getPort() > 0 ? acmeUrl.getPort() : acmeUrl.getDefaultPort();
            
            log.info("测试与ACME服务器的连接: {}:{}", acmeServer, port);
            result.put("acmeServer", acmeServer);
            result.put("port", port);
            
            // 测试DNS解析
            try {
                InetAddress acmeAddress = InetAddress.getByName(acmeServer);
                result.put("dnsResolution", true);
                result.put("ipAddress", acmeAddress.getHostAddress());
                
                // 测试可达性
                boolean reachable = acmeAddress.isReachable(5000);
                result.put("reachable", reachable);
                
                // 测试端口连通性
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress(acmeAddress, port), 5000);
                    result.put("portConnectivity", true);
                } catch (Exception e) {
                    result.put("portConnectivity", false);
                    result.put("portError", e.getMessage());
                    log.error("无法连接到ACME服务器端口: {}:{}", acmeServer, port, e);
                }
            } catch (Exception e) {
                result.put("dnsResolution", false);
                result.put("dnsError", e.getMessage());
                log.error("无法解析ACME服务器DNS: {}", acmeServer, e);
            }
            
            // 测试HTTPS连接
            try {
                // 创建信任所有证书的SSL上下文
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, new javax.net.ssl.TrustManager[] { 
                    new javax.net.ssl.X509TrustManager() {
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                    }
                }, new SecureRandom());
                
                // 创建HttpsURLConnection并配置
                HttpsURLConnection conn = (HttpsURLConnection) acmeUrl.openConnection();
                conn.setSSLSocketFactory(sslContext.getSocketFactory());
                conn.setHostnameVerifier((hostname, session) -> true);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestMethod("GET");
                
                // 获取响应
                int responseCode = conn.getResponseCode();
                result.put("httpsConnectivity", true);
                result.put("responseCode", responseCode);
                
                // 读取响应内容
                if (responseCode == 200) {
                    try (BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()))) {
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        result.put("response", response.toString());
                    }
                }
                
                log.info("成功连接到ACME服务器: {}, 响应码: {}", acmeUrl, responseCode);
            } catch (Exception e) {
                result.put("httpsConnectivity", false);
                result.put("httpsError", e.getMessage());
                log.error("HTTPS连接测试失败: {}", acmeUrl, e);
            }
            
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
            log.error("ACME服务器连接测试失败", e);
        }
        
        return result;
    }
    
    /**
     * 配置HTTPS请求信任Step CA证书
     * 用于解决ACME客户端的SSL验证问题
     */
    public void configureHttpsForStepCA() {
        try {
            log.info("配置HTTPS信任所有证书...");
            
            // 创建一个信任所有证书的TrustManager
            javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[] {
                new javax.net.ssl.X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                }
            };
            
            // 创建SSL上下文并初始化
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustAllCerts, new SecureRandom());
            
            // 设置默认的SSLSocketFactory
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            
            // 创建一个信任所有主机名的HostnameVerifier
            javax.net.ssl.HostnameVerifier allHostsValid = (hostname, session) -> true;
            
            // 设置默认的HostnameVerifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
            
            // 设置系统属性
            System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
            System.setProperty("javax.net.ssl.trustStore", "NONE");
            System.setProperty("com.sun.net.ssl.checkRevocation", "false");
            
            log.info("成功配置HTTPS信任所有证书");
        } catch (Exception e) {
            log.error("配置HTTPS信任所有证书失败", e);
        }
    }

@PostConstruct
public void init() {
    createDirectories();
    configureHttpsForStepCA();
    
    // 测试ACME服务器连接
    try {
        Map<String, Object> testResult = testAcmeServerConnection();
        log.info("ACME服务器连接测试结果: {}", testResult);
        
        // 如果连接测试失败，记录警告
        if (!(Boolean)testResult.getOrDefault("success", false)) {
            log.warn("无法连接到ACME服务器，证书签发可能会失败");
        }
    } catch (Exception e) {
        log.error("ACME服务器连接测试异常", e);
    }
}





    private String saveKeyPair(KeyPair keyPair, String domainName) throws Exception {
        String fileName = domainName.replace("*", "wildcard").replace(".", "_") + ".key";
        Path keyPath = Paths.get(KEYS_DIR, fileName);
        
        try (FileOutputStream fos = new FileOutputStream(keyPath.toFile());
             JcaPEMWriter pemWriter = new JcaPEMWriter(new OutputStreamWriter(fos))) {
            pemWriter.writeObject(keyPair.getPrivate());
        }
        
        return keyPath.toString();
    }

    private String generateCSR(KeyPair keyPair, String domainName) throws Exception {
        // 使用ProcessBuilder执行step命令生成CSR
        String csrFileName = domainName.replace("*", "wildcard").replace(".", "_") + ".csr";
        Path csrPath = Paths.get(STEP_CA_DIR, csrFileName);
        
        // 如果CSR文件已存在，先删除它
        try {
            Files.deleteIfExists(csrPath);
        } catch (IOException e) {
            log.warn("删除已存在的CSR文件失败: {}", csrPath, e);
        }
        
        // 保存私钥到临时文件
        String tempKeyFileName = domainName.replace("*", "wildcard").replace(".", "_") + "_temp.key";
        Path tempKeyPath = Paths.get(STEP_CA_DIR, tempKeyFileName);
        try (FileOutputStream fos = new FileOutputStream(tempKeyPath.toFile());
             JcaPEMWriter pemWriter = new JcaPEMWriter(new OutputStreamWriter(fos))) {
            pemWriter.writeObject(keyPair.getPrivate());
        }
        
        // 构建step命令生成CSR
        List<String> command = new ArrayList<>();
        command.add("step");
        command.add("certificate");
        command.add("create");
        command.add(domainName);
        command.add(csrPath.toString());
        command.add("--key");
        command.add(tempKeyPath.toString());
        command.add("--no-password");
        command.add("--insecure");
        command.add("--csr"); // 添加--csr标志以生成CSR而不是证书
        command.add("--force"); // 添加--force标志以自动覆盖已存在的文件
        
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true); // 将错误输出合并到标准输出
        Process process = pb.start();
        
        // 捕获标准输出
        StringBuilder output = new StringBuilder();
        
        try (BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = stdInput.readLine()) != null) {
                output.append(line).append("\n");
            }
        }
        
        int exitCode = process.waitFor();
        
        // 删除临时私钥文件
        Files.deleteIfExists(tempKeyPath);
        
        if (exitCode != 0) {
            log.error("生成CSR失败。命令: {}", String.join(" ", command));
            log.error("退出代码: {}", exitCode);
            log.error("输出: {}", output.toString());
            throw new Exception("为域名生成CSR失败: " + domainName + "。错误: " + output.toString());
        }
        
        // 验证CSR文件是否成功创建
        if (!Files.exists(csrPath)) {
            throw new Exception("CSR文件未在以下位置创建: " + csrPath);
        }
        
        return csrPath.toString();
    }

    private String requestCertificateFromStepCA(String csrPath, String domainName) throws Exception {
        // 使用ProcessBuilder执行step命令请求证书
        String certFileName = domainName.replace("*", "wildcard").replace(".", "_") + ".crt";
        Path certPath = Paths.get(CERTS_DIR, certFileName);
        
        // 为新证书创建一个密钥文件路径
        String keyFileName = domainName.replace("*", "wildcard").replace(".", "_") + "_step.key";
        Path keyPath = Paths.get(KEYS_DIR, keyFileName);
        
        List<String> command = new ArrayList<>();
        
        // 使用正确的命令：step ca sign 而不是 step ca certificate
        command.add("step");
        command.add("ca");
        command.add("sign");
        command.add("--ca-url");
        command.add(stepCAServerUrl);
        command.add("--provisioner");
        command.add(stepCAProvisioner);
        command.add("--force");
        
        // 添加根证书路径或令牌认证
        // 方法1：使用根证书路径
        command.add("--root");
        command.add(Paths.get(STEP_CA_DIR, "root_ca.crt").toString());
        
        // 或者方法2：使用令牌认证（如果有）
        // command.add("--token");
        // command.add("your-token-here");
        
        command.add(csrPath);
        command.add(certPath.toString());
        
        ProcessBuilder pb = new ProcessBuilder(command);
        Process process = pb.start();
        
        // 捕获标准输出和错误输出
        StringBuilder output = new StringBuilder();
        StringBuilder error = new StringBuilder();
        
        try (BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
             BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            
            String line;
            while ((line = stdInput.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            while ((line = stdError.readLine()) != null) {
                error.append(line).append("\n");
            }
        }
        
        int exitCode = process.waitFor();
        
        if (exitCode != 0) {
            log.error("Failed to request certificate. Command: {}", String.join(" ", command));
            log.error("Exit code: {}", exitCode);
            log.error("Standard output: {}", output.toString());
            log.error("Error output: {}", error.toString());
            throw new Exception("Failed to request certificate from Step-CA for domain: " + domainName + ". Error: " + error.toString());
        }
        
        // 返回证书路径
        return certPath.toString();
    }

    private X509Certificate readCertificate(String certPath) throws CertificateException, IOException {
        try (FileInputStream fis = new FileInputStream(certPath)) {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            return (X509Certificate) cf.generateCertificate(fis);
        }
    }

    @Override
    public boolean validateCertificate(Domain domain) {
        if (domain.getCertificatePath() == null || domain.getCertificateExpiresAt() == null) {
            return false;
        }
        
        // 检查证书是否过期
        LocalDateTime now = LocalDateTime.now();
        return now.isBefore(domain.getCertificateExpiresAt());
    }

    @Override
    public Domain revokeCertificate(Domain domain) throws Exception {
        if (domain.getCertificatePath() != null) {
            // 使用ProcessBuilder执行step命令撤销证书
            List<String> command = new ArrayList<>();
            command.add("step");
            command.add("ca");
            command.add("revoke");
            command.add("--cert");
            command.add(domain.getCertificatePath());
            command.add("--key");
            command.add(domain.getPrivateKeyPath());
            command.add("--ca-url");
            command.add(stepCAServerUrl);
            
            ProcessBuilder pb = new ProcessBuilder(command);
            Process process = pb.start();
            process.waitFor();
            
            // 删除证书和密钥文件
            Files.deleteIfExists(Paths.get(domain.getCertificatePath()));
            Files.deleteIfExists(Paths.get(domain.getPrivateKeyPath()));
        }
        
        // 更新域名信息
        domain.setCertificatePath(null);
        domain.setPrivateKeyPath(null);
        domain.setCertificateIssuedAt(null);
        domain.setCertificateExpiresAt(null);
        
        return domainRepository.save(domain);
    }

    @Override
    public Domain renewCertificate(Domain domain) throws Exception {
        // 撤销旧证书并签发新证书
        revokeCertificate(domain);
        return issueCertificate(domain);
    }
    
    /**
     * 下载Step CA根证书
     * @param outputPath 输出路径
     * @throws Exception 如果下载失败
     */
    public void downloadRootCertificate(String outputPath) throws Exception {
        log.info("Downloading Step CA root certificate...");
        
        // 构建下载根证书的命令
        List<String> command = new ArrayList<>();
        command.add("step");
        command.add("ca");
        command.add("root");
        command.add(outputPath);
        command.add("--ca-url");
        command.add(stepCAServerUrl);
        
        // 如果有指纹，则添加指纹验证
        // command.add("--fingerprint"); 
        // command.add("YOUR_ROOT_CA_FINGERPRINT"); 
        
        // 添加--insecure标志以跳过指纹验证
        command.add("--insecure");
        
        ProcessBuilder pb = new ProcessBuilder(command);
        Process process = pb.start();
        
        // 捕获输出
        StringBuilder output = new StringBuilder();
        StringBuilder error = new StringBuilder();
        
        try (BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
             BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            
            String line;
            while ((line = stdInput.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            while ((line = stdError.readLine()) != null) {
                error.append(line).append("\n");
            }
        }
        
        int exitCode = process.waitFor();
        
        if (exitCode != 0) {
            log.error("Failed to download root certificate. Command: {}", String.join(" ", command));
            log.error("Exit code: {}", exitCode);
            log.error("Output: {}", output.toString());
            log.error("Error: {}", error.toString());
            throw new Exception("Failed to download Step CA root certificate: " + error.toString());
        }
        
        log.info("Successfully downloaded Step CA root certificate to: {}", outputPath);
    }

    /**
     * 获取Step CA服务器URL
     */
    public String getCAServerUrl() {
        return stepCAServerUrl;
    }
    
    /**
     * 获取Step CA提供者
     */
    public String getCAProvisioner() {
        return stepCAProvisioner;
    }
}