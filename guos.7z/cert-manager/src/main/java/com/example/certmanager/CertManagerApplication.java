package com.example.certmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CertManagerApplication.class, args);
	}

}