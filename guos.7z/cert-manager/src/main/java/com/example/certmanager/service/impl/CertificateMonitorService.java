package com.example.certmanager.service.impl;

import com.example.certmanager.model.Domain;
import com.example.certmanager.repository.DomainRepository;
import com.example.certmanager.service.DomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * 证书监控服务
 * 用于监控证书过期时间并自动续期
 */
@Slf4j
@Service
public class CertificateMonitorService {

    private final DomainRepository domainRepository;
    private final DomainService domainService;

    @Autowired
    public CertificateMonitorService(DomainRepository domainRepository, DomainService domainService) {
        this.domainRepository = domainRepository;
        this.domainService = domainService;
    }

    /**
     * 检查即将过期的证书并自动续期
     * 每天凌晨1点执行
     */
    @Scheduled(cron = "0 0 1 * * ?")
    public void checkExpiringCertificates() {
        log.info("Starting scheduled certificate expiration check");
        
        // 查找30天内即将过期的证书
        LocalDateTime expiryThreshold = LocalDateTime.now().plusDays(30);
        List<Domain> expiringDomains = domainRepository.findByActiveTrueAndCertificateExpiresAtBefore(expiryThreshold);
        
        log.info("Found {} domains with certificates expiring within 30 days", expiringDomains.size());
        
        for (Domain domain : expiringDomains) {
            try {
                // 计算证书剩余有效期（天）
                long daysUntilExpiry = ChronoUnit.DAYS.between(LocalDateTime.now(), domain.getCertificateExpiresAt());
                
                log.info("Domain: {}, Certificate expires in {} days", domain.getDomainName(), daysUntilExpiry);
                
                // 如果证书在7天内过期，则自动续期
                if (daysUntilExpiry <= 7) {
                    log.info("Automatically renewing certificate for domain: {}", domain.getDomainName());
                    domainService.renewCertificate(domain.getId());
                    log.info("Certificate renewal completed for domain: {}", domain.getDomainName());
                }
            } catch (Exception e) {
                log.error("Failed to renew certificate for domain: {}", domain.getDomainName(), e);
            }
        }
        
        log.info("Scheduled certificate expiration check completed");
    }
    
    /**
     * 生成证书过期报告
     * 每周一早上9点执行
     */
    @Scheduled(cron = "0 0 9 ? * MON")
    public void generateExpirationReport() {
        log.info("Generating certificate expiration report");
        
        // 查找所有有效域名
        List<Domain> allActiveDomains = domainRepository.findByActive(true);
        
        int validCerts = 0;
        int expiredCerts = 0;
        int expiringWithin30Days = 0;
        int expiringWithin7Days = 0;
        int noCertificates = 0;
        
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime next7Days = now.plusDays(7);
        LocalDateTime next30Days = now.plusDays(30);
        
        for (Domain domain : allActiveDomains) {
            if (domain.getCertificateExpiresAt() == null) {
                noCertificates++;
            } else if (domain.getCertificateExpiresAt().isBefore(now)) {
                expiredCerts++;
            } else if (domain.getCertificateExpiresAt().isBefore(next7Days)) {
                expiringWithin7Days++;
            } else if (domain.getCertificateExpiresAt().isBefore(next30Days)) {
                expiringWithin30Days++;
            } else {
                validCerts++;
            }
        }
        
        log.info("Certificate Expiration Report:");
        log.info("Total active domains: {}", allActiveDomains.size());
        log.info("Domains without certificates: {}", noCertificates);
        log.info("Domains with expired certificates: {}", expiredCerts);
        log.info("Domains with certificates expiring within 7 days: {}", expiringWithin7Days);
        log.info("Domains with certificates expiring within 30 days: {}", expiringWithin30Days);
        log.info("Domains with valid certificates: {}", validCerts);
        log.info("Report generation completed");
    }
}