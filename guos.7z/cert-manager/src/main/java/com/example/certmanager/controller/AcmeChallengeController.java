package com.example.certmanager.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 处理ACME挑战的控制器
 * 用于Let's Encrypt证书签发过程中的域名所有权验证
 */
@Slf4j
@RestController
@RequestMapping("/.well-known/acme-challenge")
public class AcmeChallengeController {

    // 存储挑战令牌和对应的授权内容
    private static final Map<String, String> CHALLENGE_MAP = new ConcurrentHashMap<>();
    
    // 存储DNS-01挑战的域名和对应的TXT记录值
    private static final Map<String, String> DNS_CHALLENGE_MAP = new ConcurrentHashMap<>();

    /**
     * 添加HTTP-01挑战令牌和授权内容到映射中
     * @param token 挑战令牌
     * @param authorization 授权内容
     */
    public static void addChallenge(String token, String authorization) {
        log.info("Adding HTTP-01 challenge: token={}", token);
        CHALLENGE_MAP.put(token, authorization);
    }

    /**
     * 从映射中移除HTTP-01挑战令牌
     * @param token 挑战令牌
     */
    public static void removeChallenge(String token) {
        log.info("Removing HTTP-01 challenge: token={}", token);
        CHALLENGE_MAP.remove(token);
    }
    
    /**
     * 添加DNS-01挑战信息
     * @param domain 域名
     * @param txtValue TXT记录值
     */
    public static void addDnsChallenge(String domain, String txtValue) {
        log.info("Adding DNS-01 challenge: domain={}, txtValue={}", domain, txtValue);
        DNS_CHALLENGE_MAP.put(domain, txtValue);
    }
    
    /**
     * 移除DNS-01挑战信息
     * @param domain 域名
     */
    public static void removeDnsChallenge(String domain) {
        log.info("Removing DNS-01 challenge: domain={}", domain);
        DNS_CHALLENGE_MAP.remove(domain);
    }
    
    /**
     * 获取DNS-01挑战的TXT记录值
     * @param domain 域名
     * @return TXT记录值，如果不存在则返回null
     */
    public static String getDnsTxtValue(String domain) {
        return DNS_CHALLENGE_MAP.get(domain);
    }
    
    /**
     * 检查DNS-01挑战是否已配置
     * @param domain 域名
     * @return 如果已配置则返回true，否则返回false
     */
    public static boolean hasDnsChallenge(String domain) {
        return DNS_CHALLENGE_MAP.containsKey(domain);
    }

    /**
     * 处理HTTP-01 ACME挑战请求
     * @param token 挑战令牌
     * @return 授权内容
     */
    @GetMapping(value = "/{token}", produces = MediaType.TEXT_PLAIN_VALUE)
    public String handleChallenge(@PathVariable("token") String token) {
        log.info("Received HTTP-01 challenge request for token: {}", token);
        String authorization = CHALLENGE_MAP.get(token);
        
        if (authorization == null) {
            log.warn("No authorization found for token: {}", token);
            return "Challenge not found";
        }
        
        log.info("Returning authorization for token: {}", token);
        return authorization;
    }
}