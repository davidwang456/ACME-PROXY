package com.certmanager.controller;

import com.certmanager.model.Domain;
import com.certmanager.repository.DomainRepository;
import com.certmanager.service.CertificateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/domains")
public class DomainController {
    
    @Autowired
    private DomainRepository domainRepository;
    
    @Autowired
    private CertificateService certificateService;
    
    @GetMapping
    public List<Domain> getAllDomains() {
        return domainRepository.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Domain> getDomainById(@PathVariable Long id) {
        Optional<Domain> domain = domainRepository.findById(id);
        return domain.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<String> registerDomain(@RequestBody Domain domain) {
        // 检查域名是否已存在
        if (domainRepository.existsByDomainName(domain.getDomainName())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("域名已存在: " + domain.getDomainName());
        }
        
        String result = certificateService.requestCertificate(domain);
        return ResponseEntity.ok(result);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDomain(@PathVariable Long id) {
        if (!domainRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        
        domainRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}