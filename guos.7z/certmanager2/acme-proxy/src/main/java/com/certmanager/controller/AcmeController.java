package com.certmanager.controller;

import com.certmanager.service.AcmeProxyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/acme")
public class AcmeController {

    @Autowired
    private AcmeProxyService acmeProxyService;
    
    @GetMapping("/directory")
    public ResponseEntity<Map<String, Object>> getDirectory() {
        return acmeProxyService.getDirectory();
    }
    
    @PostMapping("/new-nonce")
    public ResponseEntity<Void> newNonce() {
        return ResponseEntity.noContent().header("Replay-Nonce", java.util.UUID.randomUUID().toString()).build();
    }
    
    @PostMapping("/new-account")
    public ResponseEntity<Object> newAccount(@RequestBody String payload, @RequestHeader Map<String, String> headers) {
        return acmeProxyService.newAccount(payload, headers);
    }
    
    @PostMapping("/new-order")
    public ResponseEntity<Object> newOrder(@RequestBody String payload, @RequestHeader Map<String, String> headers) {
        return acmeProxyService.newOrder(payload, headers);
    }
    
    @PostMapping("/authz/{authzId}")
    public ResponseEntity<Object> getAuthorization(@PathVariable String authzId, 
                                                 @RequestBody(required = false) String payload, 
                                                 @RequestHeader Map<String, String> headers) {
        return acmeProxyService.getAuthorization(authzId, payload, headers);
    }
    
    @PostMapping("/challenge/{challengeId}")
    public ResponseEntity<Object> submitChallenge(@PathVariable String challengeId, 
                                                @RequestBody String payload, 
                                                @RequestHeader Map<String, String> headers) {
        return acmeProxyService.submitChallenge(challengeId, payload, headers);
    }
    
    @PostMapping("/order/{orderId}/finalize")
    public ResponseEntity<Object> finalizeOrder(@PathVariable String orderId, 
                                              @RequestBody String payload, 
                                              @RequestHeader Map<String, String> headers) {
        return acmeProxyService.finalizeOrder(orderId, payload, headers);
    }
    
    @GetMapping("/certificate/{certId}")
    public ResponseEntity<Object> getCertificate(@PathVariable String certId, 
                                               @RequestHeader Map<String, String> headers) {
        return acmeProxyService.getCertificate(certId, headers);
    }
    
    @PostMapping("/revoke-cert")
    public ResponseEntity<Object> revokeCertificate(@RequestBody String payload, 
                                                  @RequestHeader Map<String, String> headers) {
        return acmeProxyService.revokeCertificate(payload, headers);
    }
}