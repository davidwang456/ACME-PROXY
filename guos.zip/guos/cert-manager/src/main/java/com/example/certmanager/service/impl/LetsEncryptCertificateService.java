package com.example.certmanager.service.impl;

import com.example.certmanager.controller.AcmeChallengeController;
import com.example.certmanager.model.Domain;
import com.example.certmanager.repository.DomainRepository;
import com.example.certmanager.service.CertificateService;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.shredzone.acme4j.*;
import org.shredzone.acme4j.challenge.Http01Challenge;
import org.shredzone.acme4j.exception.AcmeException;
import org.shredzone.acme4j.util.CSRBuilder;
import org.shredzone.acme4j.util.KeyPairUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;

@Slf4j
@Service
public class LetsEncryptCertificateService implements CertificateService {

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    @Value("${acme.server.url}")
    private String acmeServerUrl;

    @Value("${server.port}")
    private int serverPort;
@Autowired
    private  DomainRepository domainRepository;
    private final String KEYS_DIR = "certificates/keys";
    private final String CERTS_DIR = "certificates/certs";

    public LetsEncryptCertificateService(DomainRepository domainRepository) {
        this.domainRepository = domainRepository;
        // 确保证书和密钥目录存在
        createDirectories();
    }

    private void createDirectories() {
        try {
            Files.createDirectories(Paths.get(KEYS_DIR));
            Files.createDirectories(Paths.get(CERTS_DIR));
        } catch (IOException e) {
            log.error("Failed to create certificate directories", e);
        }
    }

    @Override
    public KeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        return keyGen.generateKeyPair();
    }

    @Override
    public Domain issueCertificate(Domain domain) throws Exception {
        if (domain.getDomainType() != Domain.DomainType.EXTERNAL) {
            throw new IllegalArgumentException("Let's Encrypt service can only issue certificates for external domains");
        }
    
        String domainName = domain.getDomainName();
        
        // 生成域名账户密钥对
        KeyPair domainKeyPair = generateKeyPair();
        String keyPath = saveKeyPair(domainKeyPair, domainName);
        
        // 连接到ACME服务器
        Session session = new Session(acmeServerUrl);
        
        // 创建或加载账户
        KeyPair accountKeyPair = loadOrCreateAccountKeyPair();
        Account account = new AccountBuilder()
                .agreeToTermsOfService()
                .useKeyPair(accountKeyPair)
                .create(session);
        
        // 为域名请求证书
        Order order = account.newOrder().domains(domainName).create();
        
        // 处理域名验证挑战
        for (Authorization auth : order.getAuthorizations()) {
            Http01Challenge challenge = auth.findChallenge(Http01Challenge.class)
                .orElseThrow(() -> new AcmeException("Found no " + Http01Challenge.TYPE
                        + " challenge, don't know what to do..."));
    
            // 添加更详细的日志
            log.info("Processing authorization for domain: {}", auth.getIdentifier().getDomain());
            log.info("Authorization status: {}", auth.getStatus());
            
            // 这里需要实现HTTP-01挑战的响应
            log.info("Challenge token: {}", challenge.getToken());
            log.info("Challenge content: {}", challenge.getAuthorization());
            
            // 将挑战令牌和授权内容添加到AcmeChallengeController中
            AcmeChallengeController.addChallenge(challenge.getToken(), challenge.getAuthorization());
            
            // 添加验证URL的日志，帮助调试
            String challengeUrl = "http://" + domainName + "/.well-known/acme-challenge/" + challenge.getToken();
            log.info("Challenge URL that Let's Encrypt will access: {}", challengeUrl);
            
            // 触发挑战验证
            challenge.trigger();
            
            // 等待验证完成，增加超时处理
            int attempts = 0;
            int maxAttempts = 10; // 最多尝试10次
            
            while (challenge.getStatus() != Status.VALID && attempts < maxAttempts) {
                if (challenge.getStatus() == Status.INVALID) {
                    // 获取更多错误信息
                    String error = challenge.getError().map(Problem::toString).orElse("Unknown error");
                    log.error("Challenge failed: {}", error);
                    
                    // 移除挑战令牌
                    AcmeChallengeController.removeChallenge(challenge.getToken());
                    throw new AcmeException("Challenge failed: " + error);
                }
                
                log.info("Waiting for challenge validation, attempt {}/{}, current status: {}", 
                        attempts + 1, maxAttempts, challenge.getStatus());
                
                Thread.sleep(3000L);
                challenge.update();
                attempts++;
            }
            
            if (challenge.getStatus() != Status.VALID) {
                AcmeChallengeController.removeChallenge(challenge.getToken());
                throw new AcmeException("Challenge validation timed out after " + maxAttempts + " attempts");
            }
            
            log.info("Challenge validated successfully!");
            // 验证成功后移除挑战令牌
            AcmeChallengeController.removeChallenge(challenge.getToken());
        }
        
        // 生成CSR并完成订单
        CSRBuilder csrBuilder = new CSRBuilder();
        csrBuilder.addDomain(domainName);
        csrBuilder.sign(domainKeyPair);
        byte[] csr = csrBuilder.getEncoded();
        
        order.execute(csr);
        
        // 等待订单完成
        while (order.getStatus() != Status.VALID) {
            if (order.getStatus() == Status.INVALID) {
                throw new AcmeException("Order failed");
            }
            Thread.sleep(3000L);
            order.update();
        }
        
        // 获取证书并保存
        org.shredzone.acme4j.Certificate certificate = order.getCertificate();
        X509Certificate cert = certificate.getCertificate();
        String certPath = saveCertificate(cert, domainName);
        
        // 更新域名信息
        domain.setCertificatePath(certPath);
        domain.setPrivateKeyPath(keyPath);
        domain.setCertificateIssuedAt(LocalDateTime.now());
        domain.setCertificateExpiresAt(
                LocalDateTime.ofInstant(cert.getNotAfter().toInstant(), ZoneId.systemDefault()));
        
        return domainRepository.save(domain);
    }

    private KeyPair loadOrCreateAccountKeyPair() throws Exception {
        File accountKeyFile = new File(KEYS_DIR, "account.key");
        if (accountKeyFile.exists()) {
            try (FileReader fr = new FileReader(accountKeyFile)) {
                return KeyPairUtils.readKeyPair(fr);
            }
        } else {
            KeyPair keyPair = generateKeyPair();
            try (FileWriter fw = new FileWriter(accountKeyFile)) {
                KeyPairUtils.writeKeyPair(keyPair, fw);
            }
            return keyPair;
        }
    }

    private String saveKeyPair(KeyPair keyPair, String domainName) throws Exception {
        String fileName = domainName.replace("*", "wildcard").replace(".", "_") + ".key";
        Path keyPath = Paths.get(KEYS_DIR, fileName);
        
        try (FileWriter fw = new FileWriter(keyPath.toFile())) {
            KeyPairUtils.writeKeyPair(keyPair, fw);
        }
        
        return keyPath.toString();
    }

    private String saveCertificate(X509Certificate cert, String domainName) throws Exception {
        String fileName = domainName.replace("*", "wildcard").replace(".", "_") + ".crt";
        Path certPath = Paths.get(CERTS_DIR, fileName);
        
        try (FileWriter fw = new FileWriter(certPath.toFile());
             JcaPEMWriter pemWriter = new JcaPEMWriter(fw)) {
            pemWriter.writeObject(cert);
        }
        
        return certPath.toString();
    }

    @Override
    public boolean validateCertificate(Domain domain) {
        if (domain.getCertificatePath() == null || domain.getCertificateExpiresAt() == null) {
            return false;
        }
        
        // 检查证书是否过期
        LocalDateTime now = LocalDateTime.now();
        return now.isBefore(domain.getCertificateExpiresAt());
    }

    @Override
    public Domain revokeCertificate(Domain domain) throws Exception {
        // 实际应用中，这里应该调用Let's Encrypt API撤销证书
        // 简化处理，仅更新域名状态
        domain.setCertificatePath(null);
        domain.setPrivateKeyPath(null);
        domain.setCertificateIssuedAt(null);
        domain.setCertificateExpiresAt(null);
        
        return domainRepository.save(domain);
    }

    @Override
    public Domain renewCertificate(Domain domain) throws Exception {
        // 撤销旧证书并签发新证书
        revokeCertificate(domain);
        return issueCertificate(domain);
    }

    @Override
    public String getCAServerUrl() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getServerUrl'");
    }

    @Override
    public String getCAProvisioner() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getProvisioner'");
    }
}