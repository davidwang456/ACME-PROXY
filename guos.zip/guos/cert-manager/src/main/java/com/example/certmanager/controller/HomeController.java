package com.example.certmanager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 主页控制器
 * 处理根路径请求，重定向到域名列表页面
 */
@Controller
public class HomeController {

    /**
     * 将根路径请求重定向到域名列表页面
     * @return 重定向URL
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/domains";
    }
}