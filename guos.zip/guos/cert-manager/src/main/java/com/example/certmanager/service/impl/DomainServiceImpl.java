package com.example.certmanager.service.impl;

import com.example.certmanager.model.Domain;
import com.example.certmanager.repository.DomainRepository;
import com.example.certmanager.service.CertificateService;
import com.example.certmanager.service.DomainService;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class DomainServiceImpl implements DomainService {

    private final DomainRepository domainRepository;
    private final CertificateService letsEncryptCertificateService;
    private final CertificateService stepCACertificateService;

    @Autowired
    public DomainServiceImpl(
            DomainRepository domainRepository,
            @Qualifier("letsEncryptCertificateService") CertificateService letsEncryptCertificateService,
            @Qualifier("stepCACertificateService") CertificateService stepCACertificateService) {
        this.domainRepository = domainRepository;
        this.letsEncryptCertificateService = letsEncryptCertificateService;
        this.stepCACertificateService = stepCACertificateService;
    }

    @Override
    public Domain addDomain(Domain domain) {
        // 验证域名类型
        if (domain.getDomainType() == null) {
            domain.setDomainType(Domain.determineDomainType(domain.getDomainName()));
        }
        
        if (domain.getDomainType() == null) {
            throw new IllegalArgumentException("Invalid domain type for domain: " + domain.getDomainName());
        }
        
        return domainRepository.save(domain);
    }

    @Override
    public Optional<Domain> findById(Long id) {
        return domainRepository.findById(id);
    }

    @Override
    public Optional<Domain> findByDomainName(String domainName) {
        return domainRepository.findByDomainName(domainName);
    }

    @Override
    public List<Domain> findAll() {
        return domainRepository.findAll();
    }

    @Override
    public List<Domain> findByDomainType(Domain.DomainType domainType) {
        return domainRepository.findByDomainType(domainType);
    }

    @Override
    public Domain issueCertificate(Long domainId) throws Exception {
        Domain domain = domainRepository.findById(domainId)
                .orElseThrow(() -> new IllegalArgumentException("Domain not found with id: " + domainId));
        
        // 根据域名类型选择证书服务
        CertificateService certificateService = selectCertificateService(domain.getDomainType());
        
        // 签发证书
        return certificateService.issueCertificate(domain);
    }

    @Override
    public Domain revokeCertificate(Long domainId) throws Exception {
        Domain domain = domainRepository.findById(domainId)
                .orElseThrow(() -> new IllegalArgumentException("Domain not found with id: " + domainId));
        
        // 根据域名类型选择证书服务
        CertificateService certificateService = selectCertificateService(domain.getDomainType());
        
        // 撤销证书
        return certificateService.revokeCertificate(domain);
    }

    @Override
    public Domain renewCertificate(Long domainId) throws Exception {
        Domain domain = domainRepository.findById(domainId)
                .orElseThrow(() -> new IllegalArgumentException("Domain not found with id: " + domainId));
        
        // 根据域名类型选择证书服务
        CertificateService certificateService = selectCertificateService(domain.getDomainType());
        
        // 续期证书
        return certificateService.renewCertificate(domain);
    }

    @Override
    public void deleteDomain(Long id) {
        domainRepository.deleteById(id);
    }
    
    @Override
    public List<Domain> findDomainsWithExpiringCertificates(LocalDateTime expiryDate) {
        return domainRepository.findByActiveTrueAndCertificateExpiresAtBefore(expiryDate);
    }
    
    @Override
    public List<Domain> findExpiredCertificates() {
        return domainRepository.findExpiredCertificates();
    }
    
    @Override
    public boolean validateCertificate(Long domainId) {
        return domainRepository.findById(domainId)
                .map(domain -> {
                    CertificateService certificateService = selectCertificateService(domain.getDomainType());
                    return certificateService.validateCertificate(domain);
                })
                .orElse(false);
    }
    
    private CertificateService selectCertificateService(Domain.DomainType domainType) {
        switch (domainType) {
            case INTERNAL:
                return stepCACertificateService;
            case EXTERNAL:
                return letsEncryptCertificateService;
            default:
                throw new IllegalArgumentException("Unsupported domain type: " + domainType);
        }
    }

    @Override
    public Domain save(Domain domain) {
        return domainRepository.save(domain);
    }
    
    /**
     * 配置SSL信任所有证书（仅用于开发环境）
     * 解决ACME签发证书时的SSL验证错误
     */
    @PostConstruct
    public void setupSSLTrust() {
        try {
            log.info("Setting up SSL trust configuration for ACME...");
            
            // 创建一个信任所有证书的TrustManager
            javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[] {
                new javax.net.ssl.X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) { }
                }
            };
            
            // 获取SSL上下文并初始化它以使用我们的TrustManager
            javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            
            // 设置默认的SSLSocketFactory
            javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            
            // 创建一个信任所有主机名的HostnameVerifier
            javax.net.ssl.HostnameVerifier allHostsValid = (hostname, session) -> true;
            
            // 设置默认的HostnameVerifier
            javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
            
            // 为HttpClient设置SSL上下文（如果使用HttpClient）
            System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
            
            log.info("SSL trust configuration completed successfully");
        } catch (Exception e) {
            log.error("Failed to setup SSL trust configuration", e);
        }
    }
    
    /**
     * 使用ACME签发通配符证书
     * @param domainId 域名ID
     * @return 更新后的域名对象
     * @throws Exception 如果签发失败
     */
   // @Override
    @Transactional
    public Domain issueWildcardCertificate(Long domainId) throws Exception {
        Domain domain = domainRepository.findById(domainId)
                .orElseThrow(() -> new IllegalArgumentException("Domain not found with id: " + domainId));
        
        // 确保域名是通配符格式
        if (!domain.getDomainName().startsWith("*.")) {
            String wildcardDomain = "*." + domain.getDomainName();
            log.info("Converting domain {} to wildcard format: {}", domain.getDomainName(), wildcardDomain);
            domain.setDomainName(wildcardDomain);
            domain = domainRepository.save(domain);
        }
        
        // 根据域名类型选择证书服务
        CertificateService certificateService = selectCertificateService(domain.getDomainType());
        
        try {
            // 签发证书
            log.info("Issuing wildcard certificate for domain: {}", domain.getDomainName());
            Domain updatedDomain = certificateService.issueCertificate(domain);
            log.info("Successfully issued wildcard certificate for domain: {}", domain.getDomainName());
            return updatedDomain;
        } catch (Exception e) {
            log.error("Failed to issue wildcard certificate for domain: {}", domain.getDomainName(), e);
            throw new Exception("Failed to issue wildcard certificate: " + e.getMessage(), e);
        }
    }
}