package com.example.certmanager.controller;

import com.example.certmanager.model.DnsChallenge;
import com.example.certmanager.service.DnsChallengeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

/**
 * DNS挑战控制器
 * 处理DNS-01挑战的Web请求
 */
@Slf4j
@Controller
@RequestMapping("/dns-challenge")
public class DnsChallengeController {

    private final DnsChallengeService dnsChallengeService;

    @Autowired
    public DnsChallengeController(DnsChallengeService dnsChallengeService) {
        this.dnsChallengeService = dnsChallengeService;
    }

    /**
     * 显示所有DNS挑战记录
     */
    @GetMapping
    public String listChallenges(Model model) {
        List<DnsChallenge> challenges = dnsChallengeService.findAll();
        model.addAttribute("challenges", challenges);
        return "dns-challenge/list";
    }
    
    /**
     * 显示单个DNS挑战记录详情
     */
    @GetMapping("/{domain}")
    public String viewChallenge(@PathVariable String domain, Model model, RedirectAttributes redirectAttributes) {
        return dnsChallengeService.findByDomain(domain)
                .map(challenge -> {
                    model.addAttribute("challenge", challenge);
                    return "dns-challenge/view";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("error", "DNS挑战记录不存在: " + domain);
                    return "redirect:/dns-challenge";
                });
    }
    
    /**
     * 显示创建DNS挑战的表单
     */
    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("challenge", new DnsChallenge());
        return "dns-challenge/create";
    }
    
    /**
     * 处理创建DNS挑战的请求
     */
    @PostMapping("/create")
    public String createChallenge(@RequestParam String domain, 
                                 @RequestParam String rrName, 
                                 @RequestParam String txtValue,
                                 RedirectAttributes redirectAttributes) {
        try {
            DnsChallenge challenge = dnsChallengeService.createChallenge(
                    domain, rrName, txtValue, null, null, null);
            redirectAttributes.addFlashAttribute("success", "DNS挑战记录创建成功");
            return "redirect:/dns-challenge/" + domain;
        } catch (Exception e) {
            log.error("创建DNS挑战记录失败", e);
            redirectAttributes.addFlashAttribute("error", "创建DNS挑战记录失败: " + e.getMessage());
            return "redirect:/dns-challenge/create";
        }
    }
    
    /**
     * 标记DNS挑战为已完成
     */
    @PostMapping("/{domain}/complete")
    public String markAsCompleted(@PathVariable String domain, RedirectAttributes redirectAttributes) {
        try {
            dnsChallengeService.markAsCompleted(domain);
            redirectAttributes.addFlashAttribute("success", "DNS挑战已标记为完成");
        } catch (Exception e) {
            log.error("标记DNS挑战为完成失败", e);
            redirectAttributes.addFlashAttribute("error", "标记DNS挑战为完成失败: " + e.getMessage());
        }
        return "redirect:/dns-challenge/" + domain;
    }
    
    /**
     * 标记DNS挑战为失败
     */
    @PostMapping("/{domain}/fail")
    public String markAsFailed(@PathVariable String domain, 
                              @RequestParam(required = false) String errorMessage,
                              RedirectAttributes redirectAttributes) {
        try {
            dnsChallengeService.markAsFailed(domain, errorMessage);
            redirectAttributes.addFlashAttribute("success", "DNS挑战已标记为失败");
        } catch (Exception e) {
            log.error("标记DNS挑战为失败失败", e);
            redirectAttributes.addFlashAttribute("error", "标记DNS挑战为失败失败: " + e.getMessage());
        }
        return "redirect:/dns-challenge/" + domain;
    }
    
    /**
     * 删除DNS挑战记录
     */
    @PostMapping("/{domain}/delete")
    public String deleteChallenge(@PathVariable String domain, RedirectAttributes redirectAttributes) {
        try {
            dnsChallengeService.deleteChallenge(domain);
            redirectAttributes.addFlashAttribute("success", "DNS挑战记录已删除");
            return "redirect:/dns-challenge";
        } catch (Exception e) {
            log.error("删除DNS挑战记录失败", e);
            redirectAttributes.addFlashAttribute("error", "删除DNS挑战记录失败: " + e.getMessage());
            return "redirect:/dns-challenge/" + domain;
        }
    }
    
    /**
     * 清理过期的DNS挑战记录
     */
    @PostMapping("/cleanup")
    public String cleanupExpiredChallenges(@RequestParam(defaultValue = "7") int days, 
                                         RedirectAttributes redirectAttributes) {
        try {
            int count = dnsChallengeService.cleanupExpiredChallenges(days);
            redirectAttributes.addFlashAttribute("success", String.format("已清理%d条过期的DNS挑战记录", count));
        } catch (Exception e) {
            log.error("清理过期DNS挑战记录失败", e);
            redirectAttributes.addFlashAttribute("error", "清理过期DNS挑战记录失败: " + e.getMessage());
        }
        return "redirect:/dns-challenge";
    }
}
