package com.example.certmanager.repository;

import com.example.certmanager.model.DnsChallenge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * DNS挑战仓库接口
 * 用于DNS-01挑战记录的数据库操作
 */
@Repository
public interface DnsChallengeRepository extends JpaRepository<DnsChallenge, Long> {
    
    /**
     * 根据域名查找DNS挑战记录
     * @param domain 域名
     * @return DNS挑战记录
     */
    Optional<DnsChallenge> findByDomain(String domain);
    
    /**
     * 查找所有待处理的DNS挑战记录
     * @return 待处理的DNS挑战记录列表
     */
    List<DnsChallenge> findByStatus(DnsChallenge.ChallengeStatus status);
    
    /**
     * 删除指定域名的DNS挑战记录
     * @param domain 域名
     */
    void deleteByDomain(String domain);
    
    /**
     * 查找过期的DNS挑战记录
     * @param date 日期，早于此日期的记录将被视为过期
     * @return 过期的DNS挑战记录列表
     */
    @Query("SELECT d FROM DnsChallenge d WHERE d.createdAt < :date")
    List<DnsChallenge> findExpiredChallenges(LocalDateTime date);
}