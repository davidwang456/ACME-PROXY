package com.example.certmanager.service;

import com.example.certmanager.model.Domain;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 域名服务接口
 * 用于域名和证书管理的相关操作
 */
public interface DomainService {

    /**
     * 添加域名
     * @param domain 域名实体
     * @return 添加后的域名实体
     */
    Domain addDomain(Domain domain);
    
    /**
     * 根据ID查找域名
     * @param id 域名ID
     * @return 域名实体
     */
    Optional<Domain> findById(Long id);
    
    /**
     * 根据域名名称查找域名
     * @param domainName 域名名称
     * @return 域名实体
     */
    Optional<Domain> findByDomainName(String domainName);
    
    /**
     * 查找所有域名
     * @return 域名列表
     */
    List<Domain> findAll();
    
    /**
     * 根据域名类型查找域名
     * @param domainType 域名类型
     * @return 域名列表
     */
    List<Domain> findByDomainType(Domain.DomainType domainType);
    
    /**
     * 为指定域名签发证书
     * @param domainId 域名ID
     * @return 更新后的域名实体
     */
    Domain issueCertificate(Long domainId) throws Exception;
    
    /**
     * 撤销指定域名的证书
     * @param domainId 域名ID
     * @return 更新后的域名实体
     */
    Domain revokeCertificate(Long domainId) throws Exception;
    
    /**
     * 续期指定域名的证书
     * @param domainId 域名ID
     * @return 更新后的域名实体
     */
    Domain renewCertificate(Long domainId) throws Exception;
    
    /**
     * 删除域名
     * @param id 域名ID
     */
    void deleteDomain(Long id);
    
    /**
     * 查找即将过期的证书
     * @param expiryDate 过期日期阈值
     * @return 即将过期的域名列表
     */
    List<Domain> findDomainsWithExpiringCertificates(LocalDateTime expiryDate);
    
    /**
     * 查找已过期的证书
     * @return 已过期的域名列表
     */
    List<Domain> findExpiredCertificates();
    
    /**
     * 验证指定域名的证书是否有效
     * @param domainId 域名ID
     * @return 证书是否有效
     */
    boolean validateCertificate(Long domainId);

    Domain save(Domain domain);
}