package com.example.certmanager.service.impl;

import com.example.certmanager.controller.AcmeChallengeController;
import com.example.certmanager.model.DnsChallenge;
import com.example.certmanager.model.Domain;
import com.example.certmanager.repository.DnsChallengeRepository;
import com.example.certmanager.repository.DomainRepository;
import com.example.certmanager.service.DnsChallengeService;
import lombok.extern.slf4j.Slf4j;
import org.shredzone.acme4j.Authorization;
import org.shredzone.acme4j.Order;
import org.shredzone.acme4j.challenge.Dns01Challenge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * DNS挑战服务实现类
 * 用于管理DNS-01挑战的相关操作
 */
@Slf4j
@Service
public class DnsChallengeServiceImpl implements DnsChallengeService {

    private final DnsChallengeRepository dnsChallengeRepository;
    private final DomainRepository domainRepository;

    @Autowired
    public DnsChallengeServiceImpl(DnsChallengeRepository dnsChallengeRepository, DomainRepository domainRepository) {
        this.dnsChallengeRepository = dnsChallengeRepository;
        this.domainRepository = domainRepository;
    }

    @Override
    public List<DnsChallenge> findAll() {
        return dnsChallengeRepository.findAll();
    }

    @Override
    public Optional<DnsChallenge> findByDomain(String domain) {
        return dnsChallengeRepository.findByDomain(domain);
    }

    @Override
    @Transactional
    public DnsChallenge createChallenge(String domain, String rrName, String txtValue,
                                       String orderUrl, String authorizationUrl, String challengeUrl) {
        // 先删除已存在的挑战记录
        dnsChallengeRepository.findByDomain(domain).ifPresent(challenge -> {
            dnsChallengeRepository.delete(challenge);
        });

        // 创建新的挑战记录
        DnsChallenge challenge = new DnsChallenge();
        challenge.setDomain(domain);
        challenge.setRrName(rrName);
        challenge.setTxtValue(txtValue);
        challenge.setOrderUrl(orderUrl);
        challenge.setAuthorizationUrl(authorizationUrl);
        challenge.setChallengeUrl(challengeUrl);
        challenge.setStatus(DnsChallenge.ChallengeStatus.PENDING);
        challenge.setCreatedAt(LocalDateTime.now());

        // 关联域名实体
        domainRepository.findByDomainName(domain).ifPresent(challenge::setDomainEntity);

        // 添加到内存映射中，用于HTTP验证
        AcmeChallengeController.addDnsChallenge(domain, txtValue);

        return dnsChallengeRepository.save(challenge);
    }

    @Override
    @Transactional
    public DnsChallenge createChallengeFromAuthorization(String domain, Authorization authorization, Order order) {
        // 获取DNS-01挑战
        Dns01Challenge dns01Challenge = authorization.findChallenge(Dns01Challenge.TYPE)
                .map(c -> (Dns01Challenge) c)
                .orElseThrow(() -> new IllegalStateException("No DNS-01 challenge found for domain: " + domain));

        // 获取DNS记录信息
        String digest = dns01Challenge.getDigest();
        String rrName = "_acme-challenge." + domain;

        // 创建挑战记录
        return createChallenge(
                domain,
                rrName,
                digest,
                order.getLocation().toString(),
                authorization.getLocation().toString(),
                dns01Challenge.getLocation().toString()
        );
    }

    @Override
    @Transactional
    public DnsChallenge markAsCompleted(String domain) {
        return dnsChallengeRepository.findByDomain(domain)
                .map(challenge -> {
                    challenge.setStatus(DnsChallenge.ChallengeStatus.COMPLETED);
                    challenge.setCompletedAt(LocalDateTime.now());
                    return dnsChallengeRepository.save(challenge);
                })
                .orElseThrow(() -> new IllegalArgumentException("No challenge found for domain: " + domain));
    }

    @Override
    @Transactional
    public DnsChallenge markAsFailed(String domain, String errorMessage) {
        return dnsChallengeRepository.findByDomain(domain)
                .map(challenge -> {
                    challenge.setStatus(DnsChallenge.ChallengeStatus.FAILED);
                    // 可以添加错误信息字段存储错误原因
                    return dnsChallengeRepository.save(challenge);
                })
                .orElseThrow(() -> new IllegalArgumentException("No challenge found for domain: " + domain));
    }

    @Override
    @Transactional
    public void deleteChallenge(String domain) {
        dnsChallengeRepository.deleteByDomain(domain);
        // 从内存映射中移除
        AcmeChallengeController.removeDnsChallenge(domain);
    }

    @Override
    @Transactional
    public int cleanupExpiredChallenges(int days) {
        LocalDateTime expiryDate = LocalDateTime.now().minusDays(days);
        List<DnsChallenge> expiredChallenges = dnsChallengeRepository.findExpiredChallenges(expiryDate);
        
        for (DnsChallenge challenge : expiredChallenges) {
            // 从内存映射中移除
            AcmeChallengeController.removeDnsChallenge(challenge.getDomain());
        }
        
        dnsChallengeRepository.deleteAll(expiredChallenges);
        return expiredChallenges.size();
    }
    
    /**
     * 定时清理过期的DNS挑战记录
     * 每天凌晨2点执行
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void scheduledCleanup() {
        log.info("Scheduled cleanup of expired DNS challenges started");
        int count = cleanupExpiredChallenges(7); // 清理7天前的记录
        log.info("Scheduled cleanup completed. Removed {} expired DNS challenges", count);
    }
}