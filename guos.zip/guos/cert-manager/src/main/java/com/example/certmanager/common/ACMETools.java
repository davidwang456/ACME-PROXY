package com.example.certmanager.common;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.security.KeyPair;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import java.util.function.Supplier;

import org.shredzone.acme4j.Account;
import org.shredzone.acme4j.AccountBuilder;
import org.shredzone.acme4j.Authorization;
import org.shredzone.acme4j.Certificate;
import org.shredzone.acme4j.Order;
import org.shredzone.acme4j.Problem;
import org.shredzone.acme4j.Session;
import org.shredzone.acme4j.Status;
import org.shredzone.acme4j.challenge.Challenge;
import org.shredzone.acme4j.challenge.Dns01Challenge;
import org.shredzone.acme4j.challenge.Http01Challenge;
import org.shredzone.acme4j.exception.AcmeException;
import org.shredzone.acme4j.util.KeyPairUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class ACMETools {
    // Change the CA_URI to use https:// instead of acme://
   // private static final String CA_URI = "https://ca.itd.asky:9000/acme/acme/directory";
    
    // Or better yet, inject it from application properties
    @org.springframework.beans.factory.annotation.Value("${stepca.acme.directory}")
    private String caUri;
    

    // 可选：设置账户电子邮件
    private static final String ACCOUNT_EMAIL = "admin@itd.asky";

    // 如果CA需要外部账户绑定(EAB)，设置提供的KID和HMAC
    private static final String EAB_KID = null;
    private static final String EAB_HMAC = null;

    // 添加缺少的常量定义
    private static final File DOMAIN_KEY_FILE = new File("certificates/step-ca/domain.key");
    private static final File DOMAIN_CHAIN_FILE = new File("certificates/step-ca/domain-chain.crt");

    // 账户密钥对的供应商
    private static Supplier<KeyPair> ACCOUNT_KEY_SUPPLIER = () -> {
        try {
            return KeyPairUtils.createKeyPair(2048);
        } catch (Exception e) {
            throw new RuntimeException("无法创建账户密钥对", e);
        }
    };

    // 域名密钥对的供应商
    private static Supplier<KeyPair> DOMAIN_KEY_SUPPLIER = () -> {
        try {
            return KeyPairUtils.createKeyPair(4096);
        } catch (Exception e) {
            throw new RuntimeException("无法创建域名密钥对", e);
        }
    };

    // 用户密钥文件
    private static final File USER_KEY_FILE = new File("certificates/step-ca/user.key");

    // 挑战类型，对于通配符域名必须使用DNS
    private static final ChallengeType CHALLENGE_TYPE = ChallengeType.DNS;

    // 等待验证的最大时间
    private static final Duration TIMEOUT = Duration.ofSeconds(120L);

    private static final Logger LOG = LoggerFactory.getLogger(ACMETools.class);

    private enum ChallengeType {HTTP, DNS}
    
    // 新增方法：为通配符域名签发证书
    public String issueWildcardCertificate(String domainName, KeyPair domainKeyPair, String certPath) throws IOException, AcmeException, InterruptedException {
        // 确保父目录存在
        File certFile = new File(certPath);
        certFile.getParentFile().mkdirs();
        
        // 加载用户密钥对
        KeyPair userKeyPair = loadOrCreateUserKeyPair();

        // 创建会话
        Session session = new Session(caUri);

        // 获取账户
        Account acct = findOrRegisterAccount(session, userKeyPair);

        // 准备域名集合（去掉*前缀，因为我们需要验证基本域名）
        String baseDomain = domainName.substring(2); // 移除"*."前缀
        Collection<String> domains = Arrays.asList(domainName, baseDomain);

        // 下单证书
        Order order = acct.newOrder().domains(domains).create();

        // 执行所有必需的授权
        for (Authorization auth : order.getAuthorizations()) {
            authorize(auth);
        }

        // 等待订单准备就绪
        order.waitUntilReady(TIMEOUT);

        // 下单证书
        order.execute(domainKeyPair);

        // 等待订单完成
        Status status = order.waitForCompletion(TIMEOUT);
        if (status != Status.VALID) {
            LOG.error("订单失败，原因: {}", order.getError()
                    .map(Problem::toString)
                    .orElse("未知"));
            throw new AcmeException("订单失败... 放弃。");
        }

        // 获取证书
        Certificate certificate = order.getCertificate();

        LOG.info("成功！域名 {} 的证书已生成！", domains);
        LOG.info("证书URL: {}", certificate.getLocation());

        // 写入包含证书和链的组合文件
        try (FileWriter fw = new FileWriter(certFile)) {
            certificate.writeCertificate(fw);
        }

        return certPath;
    }

    /**
     * Generates a certificate for the given domains. Also takes care for the registration
     * process.
     *
     * @param domains
     *         Domains to get a common certificate for
     */
    public void fetchCertificate(Collection<String> domains) throws IOException, AcmeException, InterruptedException {
        // Load the user key file. If there is no key file, create a new one.
        KeyPair userKeyPair = loadOrCreateUserKeyPair();

        // Create a session.
        Session session = new Session(caUri);

        // Get the Account.
        // If there is no account yet, create a new one.
        Account acct = findOrRegisterAccount(session, userKeyPair);

        // Load or create a key pair for the domains. This should not be the userKeyPair!
        KeyPair domainKeyPair = loadOrCreateDomainKeyPair();

        // Order the certificate
        Order order = acct.newOrder().domains(domains).create();

        // Perform all required authorizations
        for (Authorization auth : order.getAuthorizations()) {
            authorize(auth);
        }

        // Wait for the order to become READY
        order.waitUntilReady(TIMEOUT);

        // Order the certificate
        order.execute(domainKeyPair);

        // Wait for the order to complete
        Status status = order.waitForCompletion(TIMEOUT);
        if (status != Status.VALID) {
            LOG.error("Order has failed, reason: {}", order.getError()
                    .map(Problem::toString)
                    .orElse("unknown"));
            throw new AcmeException("Order failed... Giving up.");
        }

        // Get the certificate
        Certificate certificate = order.getCertificate();

        LOG.info("Success! The certificate for domains {} has been generated!", domains);
        LOG.info("Certificate URL: {}", certificate.getLocation());

        // Write a combined file containing the certificate and chain.
        try (FileWriter fw = new FileWriter(DOMAIN_CHAIN_FILE)) {
            certificate.writeCertificate(fw);
        }

        // That's all! Configure your web server to use the DOMAIN_KEY_FILE and
        // DOMAIN_CHAIN_FILE for the requested domains.
    }

    /**
     * Loads a user key pair from {@link #USER_KEY_FILE}. If the file does not exist, a
     * new key pair is generated and saved.
     * <p>
     * Keep this key pair in a safe place! In a production environment, you will not be
     * able to access your account again if you should lose the key pair.
     *
     * @return User's {@link KeyPair}.
     */
    private KeyPair loadOrCreateUserKeyPair() throws IOException {
        if (USER_KEY_FILE.exists()) {
            // If there is a key file, read it
            try (FileReader fr = new FileReader(USER_KEY_FILE)) {
                return KeyPairUtils.readKeyPair(fr);
            }

        } else {
            // If there is none, create a new key pair and save it
            KeyPair userKeyPair = ACCOUNT_KEY_SUPPLIER.get();
            try (FileWriter fw = new FileWriter(USER_KEY_FILE)) {
                KeyPairUtils.writeKeyPair(userKeyPair, fw);
            }
            return userKeyPair;
        }
    }

    /**
     * Loads a domain key pair from {@link #DOMAIN_KEY_FILE}. If the file does not exist,
     * a new key pair is generated and saved.
     *
     * @return Domain {@link KeyPair}.
     */
    private KeyPair loadOrCreateDomainKeyPair() throws IOException {
        if (DOMAIN_KEY_FILE.exists()) {
            try (FileReader fr = new FileReader(DOMAIN_KEY_FILE)) {
                return KeyPairUtils.readKeyPair(fr);
            }
        } else {
            KeyPair domainKeyPair = DOMAIN_KEY_SUPPLIER.get();
            try (FileWriter fw = new FileWriter(DOMAIN_KEY_FILE)) {
                KeyPairUtils.writeKeyPair(domainKeyPair, fw);
            }
            return domainKeyPair;
        }
    }

    /**
     * Finds your {@link Account} at the ACME server. It will be found by your user's
     * public key. If your key is not known to the server yet, a new account will be
     * created.
     * <p>
     * This is a simple way of finding your {@link Account}. A better way is to get the
     * URL of your new account with {@link Account#getLocation()} and store it somewhere.
     * If you need to get access to your account later, reconnect to it via {@link
     * Session#login(URL, KeyPair)} by using the stored location.
     *
     * @param session
     *         {@link Session} to bind with
     * @return {@link Account}
     */
    private Account findOrRegisterAccount(Session session, KeyPair accountKey) throws AcmeException {
        // Ask the user to accept the TOS, if server provides us with a link.
       try{
        Optional<URI> tos = session.getMetadata().getTermsOfService();
        if (tos.isPresent()) {
            acceptAgreement(tos.get());
        }}catch(Exception e){
            LOG.error("无法接受服务条款", e);
        }

        AccountBuilder accountBuilder = new AccountBuilder()
                .agreeToTermsOfService()
                .useKeyPair(accountKey);

        // Set your email (if available)
        if (ACCOUNT_EMAIL != null) {
            accountBuilder.addEmail(ACCOUNT_EMAIL);
        }

        // Use the KID and HMAC if the CA uses External Account Binding
        if (EAB_KID != null && EAB_HMAC != null) {
            accountBuilder.withKeyIdentifier(EAB_KID, EAB_HMAC);
        }

        Account account = accountBuilder.create(session);
        LOG.info("Registered a new user, URL: {}", account.getLocation());

        return account;
    }

    /**
     * Authorize a domain. It will be associated with your account, so you will be able to
     * retrieve a signed certificate for the domain later.
     *
     * @param auth
     *         {@link Authorization} to perform
     */
    private void authorize(Authorization auth) throws AcmeException, InterruptedException {
        LOG.info("Authorization for domain {}", auth.getIdentifier().getDomain());

        // The authorization is already valid. No need to process a challenge.
        if (auth.getStatus() == Status.VALID) {
            return;
        }

        // Find the desired challenge and prepare it.
        Challenge challenge = null;
        switch (CHALLENGE_TYPE) {
            case HTTP:
                challenge = httpChallenge(auth);
                break;

            case DNS:
                challenge = dnsChallenge(auth);
                break;
        }

        if (challenge == null) {
            throw new AcmeException("No challenge found");
        }

        // If the challenge is already verified, there's no need to execute it again.
        if (challenge.getStatus() == Status.VALID) {
            return;
        }

        // Now trigger the challenge.
        challenge.trigger();

        // Poll for the challenge to complete.
        Status status = challenge.waitForCompletion(TIMEOUT);
        if (status != Status.VALID) {
            LOG.error("Challenge has failed, reason: {}", challenge.getError()
                    .map(Problem::toString)
                    .orElse("unknown"));
            throw new AcmeException("Challenge failed... Giving up.");
        }

        LOG.info("Challenge has been completed. Remember to remove the validation resource.");
        completeChallenge("Challenge has been completed.\nYou can remove the resource again now.");
    }

    /**
     * Prepares a HTTP challenge.
     * <p>
     * The verification of this challenge expects a file with a certain content to be
     * reachable at a given path under the domain to be tested.
     * <p>
     * This example outputs instructions that need to be executed manually. In a
     * production environment, you would rather generate this file automatically, or maybe
     * use a servlet that returns {@link Http01Challenge#getAuthorization()}.
     *
     * @param auth
     *         {@link Authorization} to find the challenge in
     * @return {@link Challenge} to verify
     */
    public Challenge httpChallenge(Authorization auth) throws AcmeException {
        // Find a single http-01 challenge
        Http01Challenge challenge = auth.findChallenge(Http01Challenge.class)
                .orElseThrow(() -> new AcmeException("Found no " + Http01Challenge.TYPE
                        + " challenge, don't know what to do..."));

        // Output the challenge, wait for acknowledge...
        LOG.info("Please create a file in your web server's base directory.");
        LOG.info("It must be reachable at: http://{}/.well-known/acme-challenge/{}",
                auth.getIdentifier().getDomain(), challenge.getToken());
        LOG.info("File name: {}", challenge.getToken());
        LOG.info("Content: {}", challenge.getAuthorization());
        LOG.info("The file must not contain any leading or trailing whitespaces or line breaks!");
        LOG.info("If you're ready, dismiss the dialog...");

        StringBuilder message = new StringBuilder();
        message.append("Please create a file in your web server's base directory.\n\n");
        message.append("http://")
                .append(auth.getIdentifier().getDomain())
                .append("/.well-known/acme-challenge/")
                .append(challenge.getToken())
                .append("\n\n");
        message.append("Content:\n\n");
        message.append(challenge.getAuthorization());
        acceptChallenge(message.toString());

        return challenge;
    }

    /**
     * Prepares a DNS challenge.
     * <p>
     * The verification of this challenge expects a TXT record with a certain content.
     * <p>
     * This example outputs instructions that need to be executed manually. In a
     * production environment, you would rather configure your DNS automatically.
     *
     * @param auth
     *         {@link Authorization} to find the challenge in
     * @return {@link Challenge} to verify
     */
    public Challenge dnsChallenge(Authorization auth) throws AcmeException {
        // Find a single dns-01 challenge
        Dns01Challenge challenge = auth.findChallenge(Dns01Challenge.TYPE)
                .map(Dns01Challenge.class::cast)
                .orElseThrow(() -> new AcmeException("Found no " + Dns01Challenge.TYPE
                        + " challenge, don't know what to do..."));

        // Output the challenge, wait for acknowledge...
        LOG.info("Please create a TXT record:");
        LOG.info("{} IN TXT {}",
                Dns01Challenge.toRRName(auth.getIdentifier()), challenge.getDigest());
        LOG.info("If you're ready, dismiss the dialog...");

        StringBuilder message = new StringBuilder();
        message.append("Please create a TXT record:\n\n");
        message.append(Dns01Challenge.toRRName(auth.getIdentifier()))
                .append(" IN TXT ")
                .append(challenge.getDigest());
        acceptChallenge(message.toString());

        return challenge;
    }

    /**
     * 处理挑战验证的准备工作
     *
     * @param message 需要显示的指令
     */
    public void acceptChallenge(String message) throws AcmeException {
        // 在Web应用中，我们不能使用JOptionPane
        // 这里只记录消息，实际应用中可能需要通过Web界面与用户交互
        LOG.info("需要完成以下挑战验证: {}", message);
        
        // 在这里，我们假设挑战已被接受
        // 在实际应用中，您可能需要实现一个Web界面来显示这些信息并等待用户确认
        
        // 如果您想要中断流程，可以抛出异常
        // throw new AcmeException("用户取消了挑战");
    }
    
    /**
     * 处理挑战完成后的操作
     *
     * @param message 需要显示的指令
     */
    public void completeChallenge(String message) {
        // 在Web应用中，我们不能使用JOptionPane
        // 这里只记录消息
        LOG.info("挑战已完成: {}", message);
        
        // 在实际应用中，您可能需要实现一个Web界面来显示这些信息
    }
    
    /**
     * 处理服务条款的接受
     *
     * @param agreement 服务条款的URI
     */
    public void acceptAgreement(URI agreement) throws AcmeException {
        // 在Web应用中，我们不能使用JOptionPane
        // 这里假设服务条款已被接受
        LOG.info("自动接受服务条款: {}", agreement);
        
        // 在实际应用中，您可能需要实现一个Web界面来显示服务条款并获取用户确认
        // 如果您想要中断流程，可以抛出异常
        // throw new AcmeException("用户不接受服务条款");
    }

    /**
     * Invokes this example.
     *
     * @param args
     *         Domains to get a certificate for
     */
    // public static void main(String... args) {
    //     if (args.length == 0) {
    //         System.err.println("Usage: ClientTest <domain>...");
    //         System.exit(1);
    //     }

    //     LOG.info("Starting up...");

    //     Security.addProvider(new BouncyCastleProvider());

    //     Collection<String> domains = Arrays.asList(args);
    //     try {
    //         ACMETools ct = new ACMETools();
    //         ct.fetchCertificate(domains);
    //     } catch (Exception ex) {
    //         LOG.error("Failed to get a certificate for domains " + domains, ex);
    //     }
    // }

}
