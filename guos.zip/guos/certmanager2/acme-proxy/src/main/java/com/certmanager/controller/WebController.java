package com.certmanager.controller;

import com.certmanager.model.Domain;
import com.certmanager.repository.DomainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
public class WebController {

    @Autowired
    private DomainRepository domainRepository;

    @GetMapping("/")
    public String index(Model model) {
        // Add the newDomain object to the model
        model.addAttribute("newDomain", new Domain());
        
        // Add the list of domains to the model
        List<Domain> domains = domainRepository.findAll();
        model.addAttribute("domains", domains);
        
        return "index";
    }
    
    @PostMapping("/register")
    public String registerDomain(@ModelAttribute Domain newDomain, RedirectAttributes redirectAttributes) {
        try {
            // Check if domain already exists
            if (domainRepository.existsByDomainName(newDomain.getDomainName())) {
                redirectAttributes.addFlashAttribute("error", "域名已存在");
                return "redirect:/";
            }
            
            // Set domain type based on domain name
            newDomain.setDomainType(Domain.determineDomainType(newDomain.getDomainName()));
            newDomain.setActive(true);
            
            // Save domain
            domainRepository.save(newDomain);
            
            redirectAttributes.addFlashAttribute("success", "域名注册成功");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "域名注册失败: " + e.getMessage());
        }
        
        return "redirect:/";
    }
    
    @GetMapping("/delete/{id}")
    public String deleteDomain(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            domainRepository.deleteById(id);
            redirectAttributes.addFlashAttribute("success", "域名删除成功");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "域名删除失败: " + e.getMessage());
        }
        
        return "redirect:/";
    }
    
    @GetMapping("/download-cert/{id}")
    public ResponseEntity<String> downloadCertificate(@PathVariable Long id) {
        // Find the domain by ID
        Optional<Domain> domainOpt = domainRepository.findById(id);
        
        if (domainOpt.isEmpty() || domainOpt.get().getCertificate() == null) {
            return ResponseEntity.notFound().build();
        }
        
        Domain domain = domainOpt.get();
        
        // Set up headers for file download
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", domain.getDomainName() + ".pem");
        
        // Return the certificate as a downloadable file
        return ResponseEntity.ok()
                .headers(headers)
                .body(domain.getCertificate());
    }
}