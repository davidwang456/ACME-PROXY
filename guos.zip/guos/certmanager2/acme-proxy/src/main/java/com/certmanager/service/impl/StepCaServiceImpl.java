package com.certmanager.service.impl;


import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.security.auth.x500.X500Principal;
@Slf4j
@Service
public class StepCaServiceImpl {

    @Value("${step-ca.url:https://step-ca:9000}")
    private String stepCaUrl;
    
    @Value("${step-ca.provisioner:acme}")
    private String provisioner;
    
    @Value("${step-ca.password:}")
    private String password;
    
    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    public String issueCertificate(String domain) {
        try {
            // 生成密钥对
            KeyPair keyPair = generateKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();
            PublicKey publicKey = keyPair.getPublic();
            
            // 构建CSR请求数据
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("csr", generateCsr(domain, keyPair));
            requestData.put("sans", new String[]{domain});
            requestData.put("provisioner", provisioner);
            
            if (password != null && !password.isEmpty()) {
                requestData.put("password", password);
            }
            
            // 设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            // 创建HTTP请求实体
            HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestData, headers);
            
            // 发送请求到step-ca服务器
            ResponseEntity<Map> response = restTemplate.exchange(
                    stepCaUrl + "/1.0/sign",
                    HttpMethod.POST,
                    requestEntity,
                    Map.class
            );
            
            // 处理响应
            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                String certificate = (String) responseBody.get("crt");
                log.info(certificate);
                // 将私钥和证书保存起来
                String privateKeyPem = convertPrivateKeyToPem(privateKey);
                
                // 返回成功信息
                return "证书签发成功，域名: " + domain;
            } else {
                return "证书签发失败，状态码: " + response.getStatusCodeValue();
            }
        } catch (Exception e) {
            return "证书签发失败: " + e.getMessage();
        }
    }
    
    /**
     * 生成密钥对
     */
    private KeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        return keyPairGenerator.generateKeyPair();
    }
    
    /**
     * 生成CSR (Certificate Signing Request)
     */
    private String generateCsr(String domain, KeyPair keyPair) throws Exception {
        // 这里使用Bouncy Castle库生成CSR
        // 简化实现，实际应用中应该使用Bouncy Castle或其他库
        
        // 模拟CSR生成
      //  String csrContent = "-----BEGIN CERTIFICATE REQUEST-----\n" +
      //                      "MIICvDCCAaQCAQAwdzELMAkGA1UEBhMCVVMxDTALBgNVBAgMBFV0YWgxDzANBgNV\n" +
      //                      "BAcMBlByb3ZvMRAwDgYDVQQKDAdFeGFtcGxlMRAwDgYDVQQLDAd0ZXN0aW5nMSYw\n" +
     //                       "JAYDVQQDDB0qLiIgKyBkb21haW4gKyAiLmV4YW1wbGUuY29tMIIBIjANBgkqhkiG\n" +
    //                        "9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0f8QvjxxlXnSUVJxZQN8RsL1cjJEhn7k9i8m\n" +
    //                        "-----END CERTIFICATE REQUEST-----";
        
        // 实际应用中应该使用以下代码生成真实的CSR
       
        PKCS10CertificationRequestBuilder p10Builder = new JcaPKCS10CertificationRequestBuilder(
                new X500Principal("CN=" + domain), 
                keyPair.getPublic()
        );
        
        JcaContentSignerBuilder csBuilder = new JcaContentSignerBuilder("SHA256withRSA");
        ContentSigner signer = csBuilder.build(keyPair.getPrivate());
        PKCS10CertificationRequest csr = p10Builder.build(signer);
        
        return Base64.getEncoder().encodeToString(csr.getEncoded());
      
        
       // return Base64.getEncoder().encodeToString(csrContent.getBytes());
    }
    
    /**
     * 将私钥转换为PEM格式
     */
    private String convertPrivateKeyToPem(PrivateKey privateKey) throws Exception {
        byte[] encoded = privateKey.getEncoded();
        String base64 = Base64.getEncoder().encodeToString(encoded);
        
        StringBuilder pemBuilder = new StringBuilder();
        pemBuilder.append("-----BEGIN PRIVATE KEY-----\n");
        
        // 将Base64字符串分割成每行64个字符
        for (int i = 0; i < base64.length(); i += 64) {
            pemBuilder.append(base64.substring(i, Math.min(i + 64, base64.length())));
            pemBuilder.append('\n');
        }
        
        pemBuilder.append("-----END PRIVATE KEY-----\n");
        return pemBuilder.toString();
    }
}