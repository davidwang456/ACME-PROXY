package com.certmanager.service.impl;

import com.certmanager.model.Domain;
import com.certmanager.repository.DomainRepository;
import com.certmanager.service.CertificateService;

import org.shredzone.acme4j.Account;
import org.shredzone.acme4j.AccountBuilder;
import org.shredzone.acme4j.Authorization;
import org.shredzone.acme4j.Certificate;
import org.shredzone.acme4j.Order;
import org.shredzone.acme4j.Session;
import org.shredzone.acme4j.Status;
import org.shredzone.acme4j.challenge.Http01Challenge;
import org.shredzone.acme4j.util.CSRBuilder;
import org.shredzone.acme4j.util.KeyPairUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.KeyPair;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CertificateServiceImpl implements CertificateService {

    @Autowired
    private DomainRepository domainRepository;
    
    @Value("${acme.internal.url:http://step-ca:9000/acme}")
    private String internalAcmeUrl;
    
    @Value("${acme.external.url:https://acme-v02.api.letsencrypt.org}")
    private String externalAcmeUrl;
    
    // 存储HTTP-01挑战的令牌和授权
    private final Map<String, String> challengeTokens = new ConcurrentHashMap<>();

    @Override
    public String requestCertificate(Domain domain) {
        try {
            // 根据域名类型选择不同的CA服务器
            String acmeServerUrl = domain.getDomainType() == Domain.DomainType.INTERNAL ? 
                    internalAcmeUrl : externalAcmeUrl;
            
            // 创建ACME会话
            Session session = new Session(acmeServerUrl);
            
            // 生成账户密钥对
            KeyPair accountKeyPair = KeyPairUtils.createKeyPair(2048);
            
            // 创建账户
            Account account = new AccountBuilder()
                    .agreeToTermsOfService()
                    .useKeyPair(accountKeyPair)
                    .create(session);
            
            // 生成域名密钥对（与账户密钥对不同）
            KeyPair domainKeyPair = KeyPairUtils.createKeyPair(2048);
            
            // 为域名创建订单
            Order order = account.newOrder().domains(domain.getDomainName()).create();
            
            // 获取授权
            for (Authorization auth : order.getAuthorizations()) {
                // 查找HTTP-01挑战
                Http01Challenge challenge = auth.findChallenge(Http01Challenge.TYPE);
                if (challenge == null) {
                    throw new Exception("未找到HTTP-01挑战");
                }
                
                // 存储挑战令牌和响应，以便验证服务器可以访问
                // 在实际应用中，您需要确保这些令牌可以通过HTTP访问
                // 例如，将它们存储在Web服务器的特定路径下
                String token = challenge.getToken();
                String authorization = challenge.getAuthorization();
                
                // 将token和authorization存储到内存中，供Web服务器访问
                challengeTokens.put(token, authorization);
                
                // 记录挑战信息
                System.out.println("域名: " + domain.getDomainName());
                System.out.println("挑战令牌: " + token);
                System.out.println("授权值: " + authorization);
                System.out.println("验证URL: http://" + domain.getDomainName() + "/.well-known/acme-challenge/" + token);
                
                // 触发挑战
                challenge.trigger();
                
                // 轮询直到授权有效或无效
                while (auth.getStatus() != Status.VALID && auth.getStatus() != Status.INVALID) {
                    // 等待一段时间
                    Thread.sleep(3000L);
                    auth.update();
                }
                
                if (auth.getStatus() != Status.VALID) {
                    throw new Exception("授权失败: " + auth.getStatus());
                }
            }
            
            // 为域名创建CSR
            CSRBuilder csrBuilder = new CSRBuilder();
            csrBuilder.addDomain(domain.getDomainName());
            csrBuilder.sign(domainKeyPair);
            
            // 使用CSR完成订单
            order.execute(csrBuilder.getEncoded());
            
            // 等待订单完成
            while (order.getStatus() != Status.VALID && order.getStatus() != Status.INVALID) {
                // 等待一段时间
                Thread.sleep(3000L);
                order.update();
            }
            
            if (order.getStatus() != Status.VALID) {
                throw new Exception("订单失败: " + order.getStatus());
            }
            
            // 获取证书
            Certificate certificate = order.getCertificate();
            if (certificate == null) {
                throw new Exception("未颁发证书");
            }
            
            // 获取证书链并转换为PEM格式
            String certChain = convertCertificatesToPem(certificate.getCertificateChain());
            
            // 设置证书和相关信息
            domain.setCertificate(certChain);
            domain.setCertificateIssuedAt(LocalDateTime.now());
            
            // 从证书中提取过期时间
            X509Certificate x509Cert = certificate.getCertificateChain().get(0);
            LocalDateTime expiryDate = LocalDateTime.ofInstant(
                    x509Cert.getNotAfter().toInstant(), 
                    ZoneId.systemDefault());
            domain.setCertificateExpiresAt(expiryDate);
            
            // 设置域名状态为活跃
            domain.setActive(true);
            
            // 保存域名信息
            domainRepository.save(domain);
            
            return "证书申请成功，域名: " + domain.getDomainName();
        } catch (Exception e) {
            return "证书申请失败: " + e.getMessage();
        }
    }

    @Override
    public String issueCertificateWithCsr(String domainName, String csrContent, Domain.DomainType domainType) {
        try {
            // 检查域名是否已存在
            if (domainRepository.existsByDomainName(domainName)) {
                return "域名已存在: " + domainName;
            }
            
            // 创建新域名
            Domain domain = new Domain();
            domain.setDomainName(domainName);
            domain.setDomainType(domainType);
            
            // 根据域名类型选择不同的CA服务器
            String acmeServerUrl = domainType == Domain.DomainType.INTERNAL ? 
                    internalAcmeUrl : externalAcmeUrl;
            
            // 这里应该实现使用CSR签发证书的逻辑
            // 为了演示，我们只是模拟证书签发
            simulateIssueCertificate(domain);
            
            // 保存域名信息
            domainRepository.save(domain);
            
            return "使用CSR签发证书成功，域名: " + domainName;
        } catch (Exception e) {
            return "使用CSR签发证书失败: " + e.getMessage();
        }
    }
    
    /**
     * 模拟证书签发过程
     */
    private void simulateIssueCertificate(Domain domain) {
        // 设置证书签发时间和过期时间
        LocalDateTime now = LocalDateTime.now();
        domain.setCertificateIssuedAt(now);
        domain.setCertificateExpiresAt(now.plusMonths(3)); // 证书有效期3个月
        
        // 设置域名状态为活跃
        domain.setActive(true);
        
        // 模拟证书内容（实际应用中应该是真实的证书内容）
        String fakeCertificate = "-----BEGIN CERTIFICATE-----\n" +
                "MIIDazCCAlOgAwIBAgIUJlK9PGt2N1CJzEnYeRDFo+UzhxcwDQYJKoZIhvcNAQEL\n" +
                "BQAwQTELMAkGA1UEBhMCQ04xEDAOBgNVBAgMB0JlaWppbmcxEDAOBgNVBAcMB0Jl\n" +
                "aWppbmcxDjAMBgNVBAoMBUFDTUVDMB4XDTIzMDMzMDEwMTUwOFoXDTI0MDMzMDEw\n" +
                "MTUwOFowQTELMAkGA1UEBhMCQ04xEDAOBgNVBAgMB0JlaWppbmcxEDAOBgNVBAcM\n" +
                "B0JlaWppbmcxDjAMBgNVBAoMBUFDTUVDMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A\n" +
                "MIIBCgKCAQEA0f8QvjxxlXnSUVJxZQN8RsL1cjJEhn7k9i8mGFx7JfUgD/5OHOtA\n" +
                "-----END CERTIFICATE-----";
        domain.setCertificate(fakeCertificate);
    }
    
    /**
     * 将X509Certificate列表转换为PEM格式字符串
     */
    private String convertCertificatesToPem(List<X509Certificate> certificates) throws Exception {
        StringBuilder pemBuilder = new StringBuilder();
        
        for (X509Certificate cert : certificates) {
            pemBuilder.append("-----BEGIN CERTIFICATE-----\n");
            
            // 将证书转换为Base64编码字符串
            byte[] encodedCert = cert.getEncoded();
            String base64Cert = java.util.Base64.getEncoder().encodeToString(encodedCert);
            
            // 将Base64字符串分割成每行64个字符
            for (int i = 0; i < base64Cert.length(); i += 64) {
                pemBuilder.append(base64Cert.substring(i, Math.min(i + 64, base64Cert.length())));
                pemBuilder.append('\n');
            }
            
            pemBuilder.append("-----END CERTIFICATE-----\n");
        }
        
        return pemBuilder.toString();
    }
    
    /**
     * 获取挑战授权值
     * @param token 挑战令牌
     * @return 授权值，如果不存在则返回null
     */
    public String getChallengeAuthorization(String token) {
        return challengeTokens.get(token);
    }
}