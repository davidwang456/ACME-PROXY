package com.certmanager.service.impl;

import com.certmanager.model.Domain;
import com.certmanager.repository.DomainRepository;
import com.certmanager.service.AcmeProxyService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.shredzone.acme4j.*;
import org.shredzone.acme4j.challenge.Http01Challenge;
import org.shredzone.acme4j.util.CSRBuilder;
import org.shredzone.acme4j.util.KeyPairUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import java.security.KeyPair;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@Primary
@Service
public class Acme4jProxyServiceImpl implements AcmeProxyService {

    @Autowired
    private DomainRepository domainRepository;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Value("${acme.internal.url}")
    private String internalAcmeUrl;
    
    @Value("${acme.external.url}")
    private String externalAcmeUrl;
    
    @Value("${server.url}")
    private String serverUrl;
    
    // Store challenges for HTTP-01 validation
    private final Map<String, String> challengeTokens = new ConcurrentHashMap<>();

    @Override
    public ResponseEntity<Map<String, Object>> getDirectory() {
        Map<String, Object> directory = new HashMap<>();
        
        // Set ACME directory endpoints
        directory.put("newNonce", serverUrl + "/acme/new-nonce");
        directory.put("newAccount", serverUrl + "/acme/new-account");
        directory.put("newOrder", serverUrl + "/acme/new-order");
        directory.put("revokeCert", serverUrl + "/acme/revoke-cert");
        directory.put("keyChange", serverUrl + "/acme/key-change");
        
        // Add metadata
        Map<String, Object> meta = new HashMap<>();
        meta.put("termsOfService", serverUrl+"/terms");
        meta.put("website", serverUrl);
        meta.put("caaIdentities", new String[]{serverUrl});
        meta.put("externalAccountRequired", false);
        
        directory.put("meta", meta);
        
        return ResponseEntity.ok(directory);
    }

    @Override
    public ResponseEntity<Object> newAccount(String payload, Map<String, String> headers) {
        try {
            // Extract domain from payload to determine which ACME server to use
            String domainName = extractDomainFromPayload(payload);
            Domain.DomainType domainType = Domain.determineDomainType(domainName);
            
            // Create account with appropriate ACME server
            String acmeServerUrl = (domainType == Domain.DomainType.INTERNAL) ? internalAcmeUrl : externalAcmeUrl;
            
            // 创建ACME会话
            Session session = new Session(acmeServerUrl);
            
            // 生成账户密钥对
            KeyPair accountKeyPair = KeyPairUtils.createKeyPair(2048);
            
            // 创建账户
            Account account = new AccountBuilder()
                    .agreeToTermsOfService()
                    .useKeyPair(accountKeyPair)
                    .create(session);
            
            // 获取账户信息
            String accountLocation = account.getLocation().toString();
            String accountId = account.getLocation().getPath().substring(account.getLocation().getPath().lastIndexOf('/') + 1);
            
            // 返回账户信息
            Map<String, Object> response = new HashMap<>();
            response.put("status", "valid");
            response.put("orders", serverUrl + "/acme/orders");
            response.put("location", accountLocation);
            response.put("id", accountId);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error creating account: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @Override
    public ResponseEntity<Object> newOrder(String payload, Map<String, String> headers) {
        try {
            // Extract domain from payload
            String domainName = extractDomainFromPayload(payload);
            Domain.DomainType domainType = Domain.determineDomainType(domainName);
            
            // Check if domain already exists
            if (domainRepository.existsByDomainName(domainName)) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("type", "urn:ietf:params:acme:error:malformed");
                errorResponse.put("detail", "Domain already registered");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
            }
            
            // Create domain entity
            Domain domain = new Domain();
            domain.setDomainName(domainName);
            domain.setDomainType(domainType);
            domain.setActive(true);
            
            // Save domain
            domainRepository.save(domain);
            
            // Create response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "pending");
            response.put("expires", Date.from(LocalDateTime.now().plusDays(7).atZone(ZoneId.systemDefault()).toInstant()).toString());
            response.put("identifiers", Map.of("type", "dns", "value", domainName));
            response.put("authorizations", new String[]{serverUrl + "/acme/authz/" + domain.getId()});
            response.put("finalize", serverUrl + "/acme/order/" + domain.getId() + "/finalize");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error creating order: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @Override
    public ResponseEntity<Object> getAuthorization(String authzId, String payload, Map<String, String> headers) {
        try {
            // Find domain by ID
            Long domainId = Long.parseLong(authzId);
            Domain domain = domainRepository.findById(domainId)
                    .orElseThrow(() -> new IllegalArgumentException("Domain not found"));
            
            // Create challenge token
            String token = generateToken();
            String keyAuthorization = token + ".dummy-key-authorization";
            challengeTokens.put(token, keyAuthorization);
            
            // Create response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "pending");
            response.put("expires", Date.from(LocalDateTime.now().plusDays(7).atZone(ZoneId.systemDefault()).toInstant()).toString());
            response.put("identifier", Map.of("type", "dns", "value", domain.getDomainName()));
            
            // Create HTTP-01 challenge
            Map<String, Object> challenge = new HashMap<>();
            challenge.put("type", "http-01");
            challenge.put("status", "pending");
            challenge.put("url", serverUrl + "/acme/challenge/" + token);
            challenge.put("token", token);
            
            response.put("challenges", new Object[]{challenge});
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error getting authorization: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @Override
    public ResponseEntity<Object> submitChallenge(String challengeId, String payload, Map<String, String> headers) {
        try {
            // Verify challenge token exists
            if (!challengeTokens.containsKey(challengeId)) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("type", "urn:ietf:params:acme:error:malformed");
                errorResponse.put("detail", "Challenge not found");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
            }
            
            // Create response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "valid");
            response.put("type", "http-01");
            response.put("url", serverUrl + "/acme/challenge/" + challengeId);
            response.put("token", challengeId);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error submitting challenge: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @Override
    public ResponseEntity<Object> finalizeOrder(String orderId, String payload, Map<String, String> headers) {
        try {
            // Find domain by ID
            Long domainId = Long.parseLong(orderId);
            Domain domain = domainRepository.findById(domainId)
                    .orElseThrow(() -> new IllegalArgumentException("Domain not found"));
            
            // Generate certificate using acme4j
            List<X509Certificate> certificates = generateCertificate(domain);
            
            // Convert certificate chain to PEM format
            String certificatePem = convertCertificatesToPem(certificates);
            
            // Update domain with certificate
            domain.setCertificate(certificatePem);
            domain.setCertificateIssuedAt(LocalDateTime.now());
            domain.setCertificateExpiresAt(LocalDateTime.now().plusMonths(3));
            domainRepository.save(domain);
            
            // Create response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "valid");
            response.put("expires", Date.from(domain.getCertificateExpiresAt().atZone(ZoneId.systemDefault()).toInstant()).toString());
            response.put("certificate", serverUrl + "/acme/certificate/" + domain.getId());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error finalizing order: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Convert X509Certificate list to PEM format string
     */
    private String convertCertificatesToPem(List<X509Certificate> certificates) throws Exception {
        StringBuilder pemBuilder = new StringBuilder();
        
        for (X509Certificate cert : certificates) {
            pemBuilder.append("-----BEGIN CERTIFICATE-----\n");
            
            // Convert certificate to Base64 encoded string
            byte[] encodedCert = cert.getEncoded();
            String base64Cert = java.util.Base64.getEncoder().encodeToString(encodedCert);
            
            // Split the Base64 string into lines of 64 characters
            for (int i = 0; i < base64Cert.length(); i += 64) {
                pemBuilder.append(base64Cert.substring(i, Math.min(i + 64, base64Cert.length())));
                pemBuilder.append('\n');
            }
            
            pemBuilder.append("-----END CERTIFICATE-----\n");
        }
        
        return pemBuilder.toString();
    }

    @Override
    public ResponseEntity<Object> getCertificate(String certId, Map<String, String> headers) {
        try {
            // Find domain by ID
            Long domainId = Long.parseLong(certId);
            Domain domain = domainRepository.findById(domainId)
                    .orElseThrow(() -> new IllegalArgumentException("Domain not found"));
            
            // Check if certificate exists
            if (domain.getCertificate() == null) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("type", "urn:ietf:params:acme:error:malformed");
                errorResponse.put("detail", "Certificate not found");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
            }
            
            // Return certificate
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.setContentType(MediaType.parseMediaType("application/pem-certificate-chain"));
            
            return ResponseEntity.ok()
                    .headers(responseHeaders)
                    .body(new String(domain.getCertificate()));
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error getting certificate: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @Override
    public ResponseEntity<Object> revokeCertificate(String payload, Map<String, String> headers) {
        try {
            // Extract domain from payload
            String domainName = extractDomainFromPayload(payload);
            
            // Find domain
            Domain domain = domainRepository.findByDomainName(domainName)
                    .orElseThrow(() -> new IllegalArgumentException("Domain not found"));
            
            // Revoke certificate
            domain.setCertificate(null);
            domain.setActive(false);
            domainRepository.save(domain);
            
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("type", "urn:ietf:params:acme:error:serverInternal");
            errorResponse.put("detail", "Error revoking certificate: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Generate a certificate for the domain using acme4j
     */
    private List<X509Certificate> generateCertificate(Domain domain) throws Exception {
        String acmeServerUrl = (domain.getDomainType() == Domain.DomainType.INTERNAL) ? internalAcmeUrl : externalAcmeUrl;
        
        // Create a session with the appropriate ACME server
        Session session = new Session(acmeServerUrl);
        
        // Generate account key pair
        KeyPair accountKeyPair = KeyPairUtils.createKeyPair(2048);
        
        // Create or load an account
        Account account = new AccountBuilder()
                .agreeToTermsOfService()
                .useKeyPair(accountKeyPair)
                .create(session);
        
        // Generate domain key pair (different from account key pair)
        KeyPair domainKeyPair = KeyPairUtils.createKeyPair(2048);
        
        // Create an order for the domain
        Order order = account.newOrder().domains(domain.getDomainName()).create();
        
        // Get the authorizations
        for (Authorization auth : order.getAuthorizations()) {
            // Find a challenge to satisfy
            Http01Challenge challenge = auth.findChallenge(Http01Challenge.TYPE);
            if (challenge == null) {
                throw new Exception("No HTTP-01 challenge found");
            }
            
            // Store the challenge token and response for validation
            challengeTokens.put(challenge.getToken(), challenge.getAuthorization());
            
            // Trigger the challenge
            challenge.trigger();
            
            // Poll until the authorization is valid or invalid
            while (auth.getStatus() != Status.VALID && auth.getStatus() != Status.INVALID) {
                // Wait a bit
                Thread.sleep(3000L);
                auth.update();
            }
            
            if (auth.getStatus() != Status.VALID) {
                throw new Exception("Authorization failed: " + auth.getStatus());
            }
        }
        
        // Create a CSR for the domain
        CSRBuilder csrBuilder = new CSRBuilder();
        csrBuilder.addDomain(domain.getDomainName());
        csrBuilder.sign(domainKeyPair);
        
        // Finalize the order with the CSR
        order.execute(csrBuilder.getEncoded());
        
        // Wait for the order to complete
        while (order.getStatus() != Status.VALID && order.getStatus() != Status.INVALID) {
            // Wait a bit
            Thread.sleep(3000L);
            order.update();
        }
        
        if (order.getStatus() != Status.VALID) {
            throw new Exception("Order failed: " + order.getStatus());
        }
        
        // Get the certificate
        Certificate certificate = order.getCertificate();
        if (certificate == null) {
            throw new Exception("No certificate issued");
        }
        
        // Return the certificate chain as PEM
        return certificate.getCertificateChain();
    }
    
    /**
     * Extract domain name from ACME request payload
     */
    private String extractDomainFromPayload(String payload) {
        try {
            Map<String, Object> requestMap = objectMapper.readValue(payload, Map.class);
            
            // Extract domain from identifiers
            if (requestMap.containsKey("identifiers")) {
                Object identifiers = requestMap.get("identifiers");
                if (identifiers instanceof Iterable) {
                    for (Object identifier : (Iterable<?>) identifiers) {
                        if (identifier instanceof Map) {
                            Map<?, ?> idMap = (Map<?, ?>) identifier;
                            if (idMap.containsKey("value")) {
                                return idMap.get("value").toString();
                            }
                        }
                    }
                }
            }
            
            // Extract domain from CSR (for finalize)
            if (requestMap.containsKey("csr")) {
                // In a real implementation, you would parse the CSR to extract the domain
                // For this example, we'll return a placeholder
                return "example.com";
            }
            
            return null;
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Generate a random token for challenges
     */
    private String generateToken() {
        return java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16);
    }
    
    // 在现有类中添加以下方法
    
    @Override
    public void generateCertificateForDomain(Domain domain) throws Exception {
        // 生成证书
        List<X509Certificate> certificates = generateCertificate(domain);
        
        // 转换为PEM格式
        String certificatePem = convertCertificatesToPem(certificates);
        
        // 更新域名信息
        domain.setCertificate(certificatePem);
        domain.setCertificateIssuedAt(LocalDateTime.now());
        domain.setCertificateExpiresAt(LocalDateTime.now().plusMonths(3));
        domain.setActive(true);
        
        // 保存域名信息
        domainRepository.save(domain);
    }
    
    @Override
    public void revokeCertificateForDomain(Domain domain) throws Exception {
        // 吊销证书
        String acmeServerUrl = (domain.getDomainType() == Domain.DomainType.INTERNAL) ? 
                internalAcmeUrl : externalAcmeUrl;
        
        // 在实际应用中，应该调用ACME服务器的吊销API
        // 这里简化处理，只更新数据库状态
        domain.setCertificate(null);
        domain.setActive(false);
        
        // 保存域名信息
        domainRepository.save(domain);
    }
    
    @Override
    public String getChallengeResponse(String token) {
        return challengeTokens.getOrDefault(token, "Challenge not found");
    }
}