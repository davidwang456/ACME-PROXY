package com.certmanager.controller;

import com.certmanager.model.Domain;
import com.certmanager.repository.DomainRepository;
import com.certmanager.service.AcmeProxyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/acme")
public class AcmeProxyController {

    @Autowired
    private AcmeProxyService acmeProxyService;
    
    @Autowired
    private DomainRepository domainRepository;
    
    @GetMapping
    public String showAcmeDashboard(Model model) {
        model.addAttribute("domains", domainRepository.findAll());
        model.addAttribute("domain", new Domain());
        return "acme/dashboard";
    }
    
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("domain", new Domain());
        model.addAttribute("domainTypes", Domain.DomainType.values());
        return "acme/register";
    }
    
    @PostMapping("/register")
    public String registerDomain(@ModelAttribute Domain domain, RedirectAttributes redirectAttributes) {
        try {
            // 检查域名是否已存在
            if (domainRepository.existsByDomainName(domain.getDomainName())) {
                redirectAttributes.addFlashAttribute("error", "域名已存在: " + domain.getDomainName());
                return "redirect:/acme/register";
            }
            
            // 保存域名信息
            domain.setActive(true);
            domainRepository.save(domain);
            
            // 使用ACME协议签发证书
            acmeProxyService.generateCertificateForDomain(domain);
            
            redirectAttributes.addFlashAttribute("success", "域名注册成功，证书已签发: " + domain.getDomainName());
            return "redirect:/acme";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "域名注册失败: " + e.getMessage());
            return "redirect:/acme/register";
        }
    }
    
    @GetMapping("/view/{id}")
    public String viewDomain(@PathVariable Long id, Model model) {
        Optional<Domain> domain = domainRepository.findById(id);
        if (domain.isPresent()) {
            model.addAttribute("domain", domain.get());
            return "acme/view";
        } else {
            return "redirect:/acme";
        }
    }
    
    @GetMapping("/revoke/{id}")
    public String showRevokePage(@PathVariable Long id, Model model) {
        Optional<Domain> domain = domainRepository.findById(id);
        if (domain.isPresent()) {
            model.addAttribute("domain", domain.get());
            return "acme/revoke";
        } else {
            return "redirect:/acme";
        }
    }
    
    @PostMapping("/revoke/{id}")
    public String revokeCertificate(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Optional<Domain> domainOpt = domainRepository.findById(id);
            if (!domainOpt.isPresent()) {
                redirectAttributes.addFlashAttribute("error", "域名不存在");
                return "redirect:/acme";
            }
            
            Domain domain = domainOpt.get();
            acmeProxyService.revokeCertificateForDomain(domain);
            
            redirectAttributes.addFlashAttribute("success", "证书已成功吊销: " + domain.getDomainName());
            return "redirect:/acme";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "证书吊销失败: " + e.getMessage());
            return "redirect:/acme";
        }
    }
    
    @GetMapping("/challenge/{token}")
    @ResponseBody
    public String handleChallenge(@PathVariable String token) {
        return acmeProxyService.getChallengeResponse(token);
    }
}