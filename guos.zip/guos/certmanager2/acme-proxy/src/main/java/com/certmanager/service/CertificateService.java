package com.certmanager.service;

import com.certmanager.model.Domain;

public interface CertificateService {
    
    /**
     * 为域名请求证书
     */
    String requestCertificate(Domain domain);
    
    /**
     * 使用CSR签发证书
     */
    String issueCertificateWithCsr(String domainName, String csrContent, Domain.DomainType domainType);
}