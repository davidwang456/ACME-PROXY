package com.certmanager.service;

import com.certmanager.model.Domain;
import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface AcmeProxyService {
    ResponseEntity<Map<String, Object>> getDirectory();
    ResponseEntity<Object> newAccount(String payload, Map<String, String> headers);
    ResponseEntity<Object> newOrder(String payload, Map<String, String> headers);
    ResponseEntity<Object> getAuthorization(String authzId, String payload, Map<String, String> headers);
    ResponseEntity<Object> submitChallenge(String challengeId, String payload, Map<String, String> headers);
    ResponseEntity<Object> finalizeOrder(String orderId, String payload, Map<String, String> headers);
    ResponseEntity<Object> getCertificate(String certId, Map<String, String> headers);
    ResponseEntity<Object> revokeCertificate(String payload, Map<String, String> headers);
    
    // 新增方法，用于前端集成
    void generateCertificateForDomain(Domain domain) throws Exception;
    void revokeCertificateForDomain(Domain domain) throws Exception;
    String getChallengeResponse(String token);
}